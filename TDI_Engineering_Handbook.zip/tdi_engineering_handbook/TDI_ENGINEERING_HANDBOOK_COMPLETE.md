# TDI Engineering Handbook — Complete Edition

**Repository-ready content, consolidated for convenient reading.** See [the handbook index](README.md) for individual chapter files.

# TDI Engineering Handbook

**Trusted Data Initiative (TDI) — Enterprise Data Platform (EDP)**  
**Primary audience:** Analytics Engineers, Data Engineers, technical reviewers and support staff  
**Working baseline:** dbt 1.12.6 and Azure Synapse Dedicated SQL Pool (database `edp`)  
**Document status:** Draft for team validation · 16 November 2026  
**Document owner:** Director of Data Operations

> **Read this first.** This handbook combines **confirmed TDI practices** with **proposed team standards**. Existing practices are labelled **Current**. New conventions and controls are labelled **Proposed** and should not be treated as approved production policy until reviewed. Example models and commands are illustrative; validate names, selectors, configurations and permissions against the live repository.

## Why this handbook exists

An engineer should be able to determine: (1) what a dataset does, (2) where it comes from, (3) what depends on it, (4) how to change it, and (5) how it reaches production. Code, dbt metadata and this handbook should agree. If they do not, raise the discrepancy and correct the authoritative source.

## Navigation

Prefer one file? Read [the complete handbook](TDI_ENGINEERING_HANDBOOK_COMPLETE.md).

| Guide | Read when you need to… |
| --- | --- |
| [01 — Architecture and data flow](docs/01-architecture-and-data-flow.md) | Understand the EDP, ingestion paths, ownership boundaries and medallion layers |
| [02 — Project structure and model conventions](docs/02-project-structure-and-conventions.md) | Find or design a dbt model, choose its materialisation and schema |
| [03 — Development workflow](docs/03-development-workflow.md) | Make a safe change from branch to pull request |
| [04 — Transformation patterns](docs/04-transformation-patterns.md) | Apply source staging, deduplication, SCD2 and domain modelling patterns |
| [05 — Orchestration and release governance](docs/05-orchestration-and-release-governance.md) | Understand selectors, jobs, approvals and rollback |
| [06 — Quality, metadata and lineage](docs/06-quality-metadata-and-lineage.md) | Write tests, document models and assess downstream impact |
| [07 — Operations, performance and troubleshooting](docs/07-operations-performance-and-troubleshooting.md) | Diagnose dbt failures and Synapse performance problems |
| [08 — New engineer onboarding](docs/08-new-engineer-onboarding.md) | Complete a guided first change and learn the system |
| [09 — Quick reference and glossary](docs/09-quick-reference-and-glossary.md) | Find commands, terms and official documentation |

### Ready-to-use templates

- [Model metadata and test template](docs/templates/model_properties.yml) (example; replace names and fields)
- [Pull request checklist](docs/templates/pull-request-template.md)
- [Architecture/engineering decision record](docs/templates/decision-record-template.md)
- [Model design note](docs/templates/model-design-note.md)

## One-minute map

```text
Source systems / datasets / files
  ├─ iPaaS for approved API, dataset and file integrations
  ├─ ACE Dynamics 365 → Synapse Link → ACE lake → ADF copy
  └─ Manual files → EDP SharePoint → iPaaS
                      ↓
                ADLS Gen2 Landing
                      ↓
      Synapse Spark notebooks, driven by source YAML
      ZIP Preprocessor / JSON Preprocessor / Bronze Processor
                      ↓
         Bronze Parquet and Delta tables in ADLS
                      ↓  append load
               Synapse Dedicated SQL Pool
                  database: edp; `_SRC` schemas
                      ↓  Azure DevOps executes dbt
           Staging / Intermediate transformations
                      ↓
       Silver: SLV_<DOMAIN> (governed domain tables)
                      ↓
       Gold: GLD_<DOMAIN> / GLD_<SUBDOMAIN>
                      ↓
        Power BI / governed semantic models / apps
```

## First-day sequence

1. Read **01**, **02** and **05** before editing production-facing models.
2. Check your approved environment, database, schema permissions and `profiles.yml` target.
3. Run `dbt --version`, `dbt debug`, `dbt parse` and `dbt ls` in your development environment.
4. Open a real Gold model; inspect its SQL, YAML, upstream `ref()` chain and consumers.
5. Follow the [onboarding exercise](docs/08-new-engineer-onboarding.md).

## Maintaining the handbook

- Documentation changes are submitted in the same pull request as the change they explain.
- Include the documentation owner and last review date in each substantial revision.
- The **dbt manifest** is authoritative for dbt model dependencies; the **Power BI lineage view** is authoritative for downstream Power BI lineage. This handbook explains intent and process, not real-time graph state.
- **Never** commit secrets, tokens, personal information or environment credentials to Markdown, YAML or example logs.
- Decisions proposed here become standards only after the appropriate engineering approval.

## Adoption checklist (for the lead reviewers)

- [ ] Verify actual folder names, dbt package and adapter versions, profiles and runtime targets.
- [ ] Replace illustrative selector names with the real `selectors.yml` names and schedule matrix.
- [ ] Confirm schema naming, tags, materialisation overrides, data classifications and owners.
- [ ] Confirm current PR branch policies and test scope; publish links to internal tooling.
- [ ] Approve or revise the **Proposed** conventions before making them mandatory.



---

# 01 — Architecture and data flow


**Status:** Current architecture, except where marked Proposed. **Scope:** Data movement and responsibilities across the EDP.

## 1.1 System at a glance

TDI operates an Azure enterprise data platform with a medallion architecture. Raw material arrives in **ADLS Gen2 Landing**. **Synapse Spark** transforms that material into structured **Bronze Parquet files and Delta tables**. Bronze data is **append-loaded** into the Synapse Dedicated SQL Pool database `edp`, in source-facing `_SRC` schemas. **dbt**, executed by **Azure DevOps**, transforms data through staging and intermediate logic into domain-specific **Silver** and **Gold** datasets. Consumers include Power BI and planned products such as DataThing and Go Global Toolkit.

The boundary matters: changes to the upstream ingestion/Bronze implementation are **Data Engineering** work; downstream Silver and Gold model changes are **Analytics Engineering** work. Platform-level changes can span both teams and must have joint review.

## 1.2 Approved ingestion routes — Current

| Route | Flow | Key point |
| --- | --- | --- |
| Standard source integration | API / dataset / file → integration designed with Integration Architect → iPaaS → Landing | Approved route for routine integrations |
| ACE Dynamics 365 | Dynamics 365 → Synapse Link → ACE lake → Azure Data Factory copy → Landing | Broad Dynamics table coverage; data is often wide and change-appended |
| Manual upload | File → EDP SharePoint → iPaaS integration → Landing | Avoid direct, unmanaged files in downstream SQL schemas |

All three routes converge on the same Landing → Bronze processing framework.

## 1.3 Bronze processing — Current

Synapse pipelines orchestrate PySpark notebooks, including:

1. **ZIP Preprocessor** — prepares compressed files where relevant.
2. **JSON Preprocessor** — prepares JSON data where relevant.
3. **Bronze Processor** — converts landed records to standardised tabular data.

A **source-specific YAML metadata profile** drives the source processing rules. The Bronze process outputs Parquet and Delta representations, after which changes are appended to Dedicated SQL Pool source tables. Confirm individual source handling and append/idempotency rules with the Data Engineering owner; do not assume every source has the same delivery frequency or change semantics.

### Three YAML concepts — do not confuse them

| File/definition | Purpose | Primary owner |
| --- | --- | --- |
| **Source YAML metadata profile** | Defines source-specific Landing/Bronze processing behaviour | Data Engineering |
| **`dbt_project.yml`** | Defines dbt project structure, materialisation defaults, model paths and configuration | Analytics Engineering, with platform oversight |
| **`profiles.yml`** | Defines dbt connection targets and credentials/secret references | Platform/Data Engineering for supported CI/CD setup; developers maintain authorised local configuration |

Never copy a production credential into a source file to simplify development.

## 1.4 Synapse Dedicated SQL Pool — Current

- Logical warehouse database: **`edp`**.
- Source-facing schemas: **`_SRC`** source tables populated after Bronze. Verify exact schema names in the live warehouse.
- Silver schemas: for example, **`SLV_TRADE`**, **`SLV_PEOPLE`**.
- Gold schemas: for example, **`GLD_TRADE`**, **`GLD_PEOPLE`**, and narrower subdomains such as **`GLD_TRADE_DEFENSE`**.
- The current pipeline builds many staging models as views; some use tables for performance. Intermediate (`int`) models are generally views, with table exceptions. Silver marts are tables. Gold marts are generally tables, with a small number of views.

These are **current tendencies**, not blanket authorisation to override a model's production config.

## 1.5 Access and consumption — Current

Access is managed through Entra ID identity/access packages. Access to a domain schema requires relevant approval; the Director of Data Operations manages schema access. **Silver domain access implies access to Gold/subdomain data for that domain** under the current entitlement structure. Users consume governed outputs primarily through Power BI reports and semantic models, with additional application consumers planned.

**Proposed:** A model design should record classification, business owner, domain, intended consumers and whether its outputs should be broadly visible to everyone with domain access. Test access implications before publishing sensitive new columns.

## 1.6 Engineering ownership and approval — Current

| Area | Builds/maintains | Final production sign-off |
| --- | --- | --- |
| Landing, Bronze, source YAML, Spark notebooks | Data Engineers | Lead Data Engineer |
| EDP platform and Azure DevOps ingestion / orchestration infrastructure | Data Engineers | Lead Data Engineer |
| Staging / intermediate / Silver / Gold transformation SQL | Analytics Engineers | Director of Data Operations for Silver and Gold changes |
| New Silver table | Analytics Engineers | **Explicit Director of Data Operations approval before production** |
| Cross-boundary change | Both teams | Relevant sign-offs for each affected area |

Reviews and approvals must follow the actual Azure DevOps branch policies. A code review is not automatically the same thing as business or production sign-off.

## 1.7 Key design principles — Proposed

1. **Use the right layer.** Do not encode business definitions in Bronze; do not make Gold silently reimplement source-cleaning logic.
2. **Lineage before change.** Trace `source()`/`ref()` links before modifying a shared model.
3. **Recoverability.** Keep the architecture recoverable from controlled source data and version-controlled transformations; avoid one-off manual repairs as the final state.
4. **Security by design.** Treat any new column or join as a potential change in data exposure.
5. **Separate observed facts and assumptions.** Record ambiguous source semantics, especially around late-arriving updates, deletions and history.

## 1.8 When to escalate

Escalate to Data Engineering for unexpected source file structures, Landing gaps, Bronze schema drift, broken append loads or ingestion configuration. Escalate to the Director of Data Operations for new Silver datasets, changes to published business definitions, changes in domain access/consumer impact or architectural exceptions.


---

# 02 — Project structure and model conventions


**Status:** Existing materialisation and naming tendencies are Current; the recommended directory and design standards below are **Proposed** until validated with the actual repository.

## 2.1 Find your way around the project

Use `dbt ls --resource-type model` to inspect actual model names and `dbt ls --output path` to see their repository paths. The recommended logical organisation is:

```text
models/
  staging/              # source preparation, naming, type harmonisation
    ace/
    trade/
    people/
  intermediate/         # reusable logic: dedup, joins, SCD2 helpers
    trade/
    people/
  silver/               # reusable governed domain tables
    trade/
    people/
  gold/                 # curated data products, domain/subdomain
    trade/
    trade_defense/
macros/                 # reusable SQL and adapter-safe utilities
seeds/                  # small governed lookup data
snapshots/              # only if used and approved in this environment
tests/                  # singular SQL assertions
selectors.yml           # selector definitions, if present
dbt_project.yml         # model and project configuration
packages.yml           # optional installed packages
```

**Important:** Folder names and SQL file names alone do not determine warehouse schemas. `dbt_project.yml`, model-level `config()`, adapter logic and custom macros can determine the final schema and alias. Check compiled output and the actual target relation.

## 2.2 Model layers and responsibilities

| Model class | Does | Does not | Current materialisation tendency |
| --- | --- | --- | --- |
| Staging (`stg_`) | Rename columns, cast types, normalize source nulls, expose a stable source vocabulary | Apply reporting-specific business definitions | View, with performance-driven table exceptions |
| Intermediate (`int_`) | Join, deduplicate, perform history and reusable transformation logic | Become an unsupported consumer-facing contract | View, with selected tables |
| Silver (`slv_`) | Produce domain-ready, governed reusable datasets with explicit grain | Embed a report-only visual calculation | Table |
| Gold (`gld_`) | Prepare consumption-ready datasets, validated aggregates and published definitions | Become an ungoverned raw source passthrough | Mostly table; occasional view |

The prefixes are recommended conventions rather than a claim that every existing file already follows them.

## 2.3 Recommended model naming

- Use lower-case `snake_case` for dbt node names and SQL file names.
- Name models by **business concept** rather than by a temporary project or a team member.
- Prefix with `stg_`, `int_`, `slv_` or `gld_` when practical.
- Avoid names like `final`, `new`, `tmp`, `v2` or `test` in production models.
- Declare intended SQL relation names and schema mappings; do not rename deployed objects casually because downstream Power BI and SQL may depend on them.

Example: `stg_ace__account`, `int_ace__account_versions`, `slv_organisation`, `gld_trade_summary`. These are **illustrative**, not actual inventory.

## 2.4 One model, one contract

Before creating a model, write down:

1. **Purpose:** what question it answers or which shared data need it meets.
2. **Grain:** what one row represents.
3. **Keys:** natural/business keys and any technical keys.
4. **Source:** upstream source or model dependencies.
5. **History:** current-state, full-history or point-in-time semantics.
6. **Update behaviour:** full rebuild, append, incremental or slowly changing history.
7. **Consumers:** downstream models, Power BI semantic models, applications.
8. **Owner/classification:** responsible domain owner and data sensitivity.
9. **Quality rules:** what must always be true.
10. **Operational profile:** approximate row count, expected refresh, key performance risks.

Use the [model design note](docs/templates/model-design-note.md) before adding a consequential Silver or Gold model.

## 2.5 SQL style — Proposed

```sql
with source_rows as (
    select
        entity_id,
        versionnumber,
        modifiedon
    from {{ ref('stg_ace__account') }}
),

filtered as (
    select *
    from source_rows
    where entity_id is not null
)

select
    entity_id,
    versionnumber,
    modifiedon
from filtered
```

- Use `{{ ref('model_name') }}` for dbt model dependencies and `{{ source('source_name', 'table_name') }}` for registered raw sources. Avoid hard-coded production database names in transformation SQL.
- Prefer explicitly selected columns in durable contracts over `select *` (especially with very wide Dynamics 365 data).
- Name intermediate CTEs for their intent, not `cte1` / `cte2`.
- Explain non-obvious business rules with brief comments; put the business meaning in YAML descriptions.
- Preserve deterministic deduplication and stable ordering for history processing.
- Do not assume every T-SQL feature supported by SQL Server also works in Synapse Dedicated SQL Pool.

## 2.6 Materialisation, distribution and indexing

**Current:** Staging/intermediate often use views; Silver and Gold generally persist tables.

**Proposed decision rules:**

- Choose a **view** for lightweight reusable logic where repeated execution is inexpensive.
- Choose a **table** when repeatedly recomputing complex joins, expensive transformations or consumer workloads would be costly.
- Discuss **incremental** models or custom materialisations with the lead reviewer before using them; verify the adapter's actual strategy and result under retry, duplicate records and backfills.
- For large tables, choose table **distribution** based on join keys and skew; `ROUND_ROBIN` is simple to load but can add data movement. Small lookup tables may suit `REPLICATE`; large joined facts often warrant evaluated `HASH` distribution.
- Avoid assuming a **clustered columnstore index** is always suitable. Very wide, low-row-count or memory-heavy tables may need another design. Evaluate rowgroup quality and load resources.

Document any overridden materialisation, distribution or index choice in the model design note, including measured evidence.

## 2.7 Tags and metadata — Proposed

Use tags for discovery and intentional selection; do **not** invent new production selector tags without reviewing existing `selectors.yml` / orchestration code.

Recommended *metadata keys* (not mandatory until approved): `domain`, `business_owner`, `technical_owner`, `classification`, `grain`, `consumers`, `refresh_expectation`, `maturity`.

```yaml
models:
  - name: slv_example_entity
    description: "Illustrative governed entity at one row per entity_id."
    config:
      meta:
        domain: example
        technical_owner: analytics_engineering
        classification: internal
        grain: one row per entity_id
    columns:
      - name: entity_id
        description: "Unique source identifier."
        data_tests:
          - not_null
          - unique
```

Where possible use actual register owner IDs and canonical classification values. `meta` keys are arbitrary data; dbt does not enforce your business rules without separate validations.

## 2.8 Before changing structure

Read `dbt_project.yml`, model configs, macros, existing YAML properties, job selectors and Power BI consumers. Confirm which choices are deliberate adaptations for Synapse performance. Never restructure the whole repository simply to match this proposed layout; migrate in reviewed increments with equivalent compiled relation names.


---

# 03 — Development workflow


**Status:** Approved production sign-off is Current; command sequence and working checklist are **Proposed** defaults. Validate actual credentials, target names and branch policies.

## 3.1 Before starting

1. Confirm a work item and expected outcome with the dataset/business owner.
2. Locate the model and read its YAML description, SQL, tests and upstream dependencies.
3. Identify all direct downstream dbt nodes and Power BI/application consumers.
4. Record whether you are changing data structure, business meaning, historical treatment, refresh logic or access exposure.
5. Confirm your development target is isolated from production and you have access to only the schemas needed.

### Safe environment checks

```bash
dbt --version
# Shows installed dbt version and adapter version.

dbt debug
# Validates local configuration and the currently selected connection target.

dbt parse
# Validates project parsing without running model SQL.

dbt ls --resource-type model
# Shows model inventory.
```

Use your team's approved `--profiles-dir`, `--target`, `--project-dir` and environment variables where applicable. Check the target printed by `dbt debug`; **do not accidentally execute builds against production**.

## 3.2 Discover dependencies and model impact

```bash
# Model and everything it depends on:
dbt ls --select "+slv_trade_transactions"

# Model and everything downstream:
dbt ls --select "slv_trade_transactions+"

# Specific resource metadata / structured output:
dbt ls --select "slv_trade_transactions" --output json

# Show a planned selection without running SQL:
dbt ls --select "path:models/silver/trade"
```

These names and paths are examples. `+` includes the selected resource itself. Separate *dbt graph impact* from *non-dbt consumers* (Power BI semantic models, reports and applications).

## 3.3 Branch, design, implement

**Proposed workflow:**

1. Create a branch linked to a work item under current Azure DevOps policy.
2. Fill out the [model design note](docs/templates/model-design-note.md) for a new or materially changed model.
3. Make the narrowest SQL change consistent with the domain definition.
4. Update YAML descriptions, keys, ownership metadata and relevant tests **in the same commit**.
5. Update the handbook or a decision record if the change adds/replaces a pattern.
6. Document any source caveats, particularly duplicate, late-arrival and history behaviour.

Avoid changing production source tables by hand to force a passing dbt build.

## 3.4 Validate locally/in development

```bash
# Parse/compile first:
dbt parse
dbt compile --select "slv_trade_transactions"

# Execute one model and its directly selected tests in a dev target:
dbt build --select "slv_trade_transactions" --target dev

# Run the selected model plus upstream parents when a clean dev environment requires them:
dbt build --select "+slv_trade_transactions" --target dev

# Test an existing selected model without rebuilding it:
dbt test --select "slv_trade_transactions" --target dev
```

**Do not assume `dev` exists**: replace it with the target name verified in `profiles.yml`. Building upstream dependencies can be costly and may touch large sources. Estimate scope with `dbt ls` before any broad selection.

### Development checks

- A model's row grain is consistent with its design note.
- Duplicate keys and unexpected `null` values are checked.
- A sample of transformed records agrees with its upstream source.
- History rules handle multiple versions, same-version duplicates and late arrival.
- Row counts, runtime and data movement are reasonable for Synapse.
- Tests do not accidentally require production-only schemas or credentials.
- Existing dependent models still compile and pass representative regression checks.

## 3.5 Pull request checklist

Copy the [PR template](docs/templates/pull-request-template.md). The description must include:

- Problem and change summary, including SQL and metadata changes.
- **Model(s), schema(s), grain, contract and ownership**.
- Impacted downstream models, reports/applications and access classification.
- Tests run, target, results and any required backfill.
- Performance evidence when large datasets are affected.
- An explicit statement if this creates a **new Silver table** (Director sign-off required).
- Recovery/rollback approach and an owner for validation after deployment.

## 3.6 Review and promote

Analytics engineers implement Silver/Gold changes; the **Director of Data Operations provides final production sign-off on these layers**. The **Lead Data Engineer** signs off production changes for Landing/Bronze/platform/CI/CD. A change involving both boundaries should have both relevant reviewers.

Follow current Azure DevOps build, test, release and approval processes. A successful local run does **not** authorise a production deployment. Approved CI/CD should be the route to publish production dbt changes.

## 3.7 After the release

1. Confirm the intended models ran in the correct environment.
2. Inspect test results, counts, runtime and dependency impacts.
3. Check sample data and critical Power BI/application consumption paths.
4. Record any regression, recovery action or follow-up work item.
5. Refresh published dbt documentation (when implemented) and relevant data product metadata.

For routine low-risk changes, the number of manual checkpoints can be reduced later through approved automation; do not skip existing authorisation requirements.


---

# 04 — Transformation patterns


**Status:** TDI Dynamics history requirement and core layer responsibilities are Current. Example SQL and recommended decision rules are Proposed.

## 4.1 Source staging — one stable vocabulary

Build staging models close to source data. A staging model should expose consistently named and typed columns while preserving essential source identifiers and change-tracking metadata.

**Recommended staging steps:**

1. Declare the input via `source()` or a documented parent `ref()`.
2. Preserve immutable source identifiers (`entity_id`, `versionnumber`, source timestamps, if available).
3. Rename source-specific fields to stable snake-case concepts.
4. Perform **safe** casts and standardise explicitly known sentinels/nulls.
5. Do not drop historical rows or silently deduplicate unless the source contract requires it and the effect is documented.
6. Keep sensitive columns only where legitimate downstream requirements exist.

```sql
-- Illustrative: fields and source name must be adapted to an actual table.
with source_rows as (
    select
        entity_id,
        versionnumber,
        modifiedon,
        name
    from {{ source('ace_src', 'account') }}
)
select
    entity_id,
    versionnumber,
    modifiedon as source_modified_at,
    name as organisation_name
from source_rows
```

**Why this matters:** Source schemas can be wide, renamed or appended over time. A predictable staging layer decouples business logic from upstream schema quirks.

## 4.2 Deduplicate deterministically

Duplicates can arise from source delivery, repeated loads or retries. Determine the logical key **before** deleting rows.

- For a current-state table, define one survivor per business key (for example, `entity_id`).
- For history, define one survivor per **business key + source version** (for example, `entity_id`, `versionnumber`).
- Choose a stable tie-breaker from available source metadata (such as event/ingestion timestamp and an immutable load ID).
- If there is no deterministic ordering column, **do not rely on arbitrary `row_number()` ordering**. Define the gap with Data Engineering first.

```sql
-- Example only: this requires a real, reliable ingestion_timestamp column.
with ranked as (
    select
        entity_id,
        versionnumber,
        ingestion_timestamp,
        row_number() over (
            partition by entity_id, versionnumber
            order by ingestion_timestamp desc
        ) as duplicate_rank
    from {{ ref('stg_ace__account') }}
)
select entity_id, versionnumber, ingestion_timestamp
from ranked
where duplicate_rank = 1
```

If two records share the same timestamp, add a stable secondary tie-breaker. Keep discarded rows discoverable for assurance where feasible.

## 4.3 Dynamics 365 version-based SCD2 — Current requirement

For Dynamics 365 data delivered through Synapse Link, TDI receives an initial snapshot followed by append-loaded changed records. **The generic history approach uses `entity_id` and the source `versionnumber`: any new version number constitutes a new entity version.** Engineers do **not** maintain per-table attribute lists to detect change. There is no separate initial-snapshot branch and no assumed `is_deleted` logic in this generic pattern.

### Required logical steps

1. Read all relevant changed rows for the entity from the source/staging table.
2. Remove duplicate deliveries of the same `(entity_id, versionnumber)` deterministically.
3. Preserve one historical record for every distinct source version per entity.
4. Order versions using a **validated version ordering rule**. Confirm its data type and behaviour for your source; do not assume lexicographic string order is correct.
5. Use `lead()` or an equivalent window expression to determine the next version boundary.
6. Assign validity start/end fields using an **approved temporal policy** (source modified timestamp where reliable; otherwise documented ingestion-effective time). The next version's effective time may be the previous version's exclusive upper bound.
7. Mark the last version as current; check exactly one current row per entity unless the dataset explicitly permits none.
8. Verify late-arriving events, ties, non-monotonic source timestamps, replays and backfills.

### Worked logical example

| entity_id | versionnumber | effective_from | effective_to (exclusive) | is_current |
| --- | --- | --- | --- | --- |
| A | 1001 | 2026-01-01 | 2026-02-04 | false |
| A | 1002 | 2026-02-04 | 2026-05-11 | false |
| A | 1004 | 2026-05-11 | NULL | true |

The dates above are **illustrative**. Source versions can skip numbers; do not invent missing versions. **Version order and temporal validity are not necessarily the same thing.** If version order conflicts with timestamps, log/resolve according to the approved history policy rather than hiding the record.

### SCD2 validation tests

- Every `(entity_id, versionnumber)` occurs once in the curated history.
- At most one `is_current = true` row per `entity_id`.
- No overlapping validity intervals for one entity.
- `valid_from < valid_to` when `valid_to` is populated.
- The expected number of versions matches distinct staged source versions (after explicitly documented exclusions).
- Business consumers can explain whether they need **current state**, **as-at time**, or **all versions**.

**Do not deploy a generic history macro until it is proven on several real tables**, including wide tables and difficult changes. A version-based strategy is simpler than attribute-by-attribute comparison, but it does not remove the need to understand source delivery semantics.

## 4.4 Silver domain models

Silver should contain **reusable domain concepts**, not assumptions tailored to a single report. A Silver model design should answer:

- What does one row mean?
- What entity identifiers and keys remain stable?
- Is this current-state or historical data?
- What transformations/filters are domain-wide, not report-specific?
- Which source and stewardship owner agrees with the definition?

**Example:** A current-state `slv_organisation` table may choose the latest valid version from an upstream version-history model, with one row per organisation; the history model itself remains accessible where there is a legitimate use case.

**Current governance:** A **new Silver table must be approved by the Director of Data Operations before production publication**.

## 4.5 Gold data products

Gold models should have an explicit **consumer contract**: report/application, business definition, grain, expected refresh and ownership. They may aggregate or denormalise Silver datasets for consumption but should not become an alternate undocumented source of master-data truth.

For a Gold aggregate, document:

- Aggregation keys and reporting period (calendar/fiscal, timezone where relevant).
- Currency, units and other dimensional filters.
- Handling of missing or invalid source values.
- Reconciliation method to the underlying Silver detail.
- Consumer responsibilities when a definition changes.

## 4.6 Full-refresh, incremental and large tables

Use persisted tables for workloads where repeated processing is costly, but make refresh and recovery behaviour explicit.

| Approach | Consider when | Required safeguards |
| --- | --- | --- |
| Full rebuild | Manageable table size; simple history or stable logic | Runtime benchmark, consistency tests, release window |
| Incremental | Large model and reliable change signal | Idempotency, late arrivals, replay/backfill design, tested adapter behaviour |
| Staged CTAS/swap | Large table replacement with tested Synapse pattern | Dependency review, rename locks, permissions, rollback and view invalidation |

**Synapse-specific caution:** A default clustered columnstore index can be counterproductive or fail under memory pressure on very wide tables. Evaluate heap/clustered-index alternatives, distribution, load resource class and rowgroup health using actual data. A `ROUND_ROBIN` distribution may load quickly but cause costly movement on joins.

## 4.7 When to write a reusable macro

Create a macro only after at least two genuine use cases confirm a shared pattern. Document inputs, assumptions, adapter constraints, compile-time SQL, error modes and tests. Genericity is helpful only when it does not conceal different business semantics. Put macro rationale in a decision record where the abstraction is consequential.


---

# 05 — Orchestration and release governance


**Status:** TDI orchestration and sign-off are Current. Proposed enhancements are labelled.

## 5.1 Production data flow and trigger — Current

After Bronze processing and append loading into Dedicated SQL Pool, the **Synapse pipeline calls the Azure DevOps API** to trigger the dbt pipeline. The pipeline prepares its execution environment, including **Python and the SQL ODBC driver**, then runs dbt against the `edp` warehouse.

### Current dbt execution order

```text
Synapse pipeline → Azure DevOps pipeline
    ├─ Install Python runtime and SQL ODBC prerequisites
    ├─ dbt seed
    ├─ dbt build: scheduled priority-100 selection(s)
    │      staging, change-key logic, SCD2 and other preparatory models
    └─ dbt build: priority-200 selection
           Silver and Gold domain/data-product models
```

The end-to-end pipeline is ordinarily **about 1–2 hours per day**, varying with data changes and scheduled sources. Do not treat that as an SLA.

**Important nuance:** dbt follows model dependency relationships within a selected build. Scheduling priority phases does not magically allow a model to run before an unbuilt dependency. Any new model must be incorporated into the appropriate phase, and the dependency graph must be valid across phases.

## 5.2 Scheduled selectors — Current conceptual overview

Existing schedules include a daily priority-100 selection, additional day-specific selections (Monday, Tuesday, Wednesday), and source-specific cadence such as **ABF in the Monday selection** and **ABS in the monthly selection**, before the priority-200 Silver/Gold work. The **actual selector names, exact arguments, schedules and source coverage must be read from the repository and Azure DevOps pipeline**.

| Execution phase | Intent | Reviewer concern |
| --- | --- | --- |
| Seed | Load small lookup datasets | Validate seed changes and downstream impact |
| Priority 100 | Stage sources; establish change keys and history | Source availability, SCD2 correctness, upstream ordering |
| Priority 200 | Build domain Silver and consumption Gold | Business semantics, model quality, consumer impact |

**Do not invent selector names.** Capture the actual `dbt build --selector …` or `--select …` arguments from the deployed YAML into an internal schedule appendix when the team reviews this handbook.

## 5.3 What a developer must check before merging

1. Does the model belong in the existing scheduled selector(s)?
2. Are all its upstream dependencies guaranteed to exist or build in an earlier/current phase?
3. Is it materialised correctly for the target dedicated SQL pool?
4. Does the change add unnecessary processing to every daily run?
5. Does it require a one-off backfill or data correction?
6. Are there warehouse concurrency, memory or storage implications?
7. Does it change access to a Silver/Gold schema or a consumer contract?

**Proposed automation:** Add CI checks to report missing model metadata, unselected new nodes, invalid cross-phase dependencies, unexpected production target configuration and unapproved schema additions.

## 5.4 Ownership and mandatory production approvals — Current

| Change | Responsible engineering area | Production authority |
| --- | --- | --- |
| Source YAML or source onboarding/Bronze Spark | Data Engineering | Lead Data Engineer |
| Synapse pipeline or Azure DevOps deployment plumbing | Data Engineering | Lead Data Engineer |
| Staging/intermediate model supporting Silver/Gold | Analytics Engineering; coordinate cross-layer implications | Follow the relevant Silver/Gold release authority where affected |
| Silver or Gold transformation | Analytics Engineering | **Director of Data Operations** |
| Any **new Silver table** | Analytics Engineering | **Explicit Director of Data Operations approval** |
| Mixed upstream and downstream change | Data + Analytics Engineering | Both relevant sign-offs |

Actual branch protection and approval records should document how sign-off is collected. Do not substitute a generic PR approval for the named release authority.

## 5.5 Release evidence — Proposed standard

Every production-facing PR should include a concise evidence set:

- Work item and source of requested business definition.
- Old/new relation names and known downstream dependencies.
- YAML descriptions/tests and test results.
- Development run logs with successful completion/known exceptions.
- Impact assessment for downstream Power BI models, reports and apps.
- Anticipated run-time/row-volume effect for large models.
- Backfill/rebuild approach if history or grain changes.
- Recovery/rollback plan and post-release verification owner.
- Required sign-off captured before deployment.

## 5.6 Rollback and recovery

dbt code can be reverted in Git, but **reverting a commit does not automatically reverse data changes**. Before a risky release, decide:

- Can the affected Silver/Gold tables be rebuilt from controlled `_SRC`/Bronze inputs?
- Is there a known-good prior table/version or alternative safe restoration method?
- Does a new column or relation create breaking downstream view/Power BI dependencies?
- Are there manual downstream changes or external consumers to coordinate?
- If a CTAS/table-swap is planned, are table renames, locks and invalidated views accounted for?

**Current architectural principle:** TDI is intended to be recoverable from Bronze and version-controlled transformations. The practical restore steps and recovery times vary by system and should be exercised, not assumed.

### Incident escalation

- **Landing/Bronze `_SRC` problem:** contact Data Engineering / Lead Data Engineer.
- **dbt Silver/Gold logic, data quality, failed build:** contact Analytics Engineering and notify the Director when production/data-product impact exists.
- **SQL pool performance or cross-platform outage:** coordinate both teams and platform support.
- **Incorrect business definition or access exposure:** involve the accountable business owner and Director immediately.

## 5.7 Enhancements to prioritise — Proposed

1. Generate `manifest.json` and `run_results.json` for every production run; retain artifacts securely according to policy.
2. Publish a schedule/selector inventory and show missing model coverage.
3. Publish dbt Docs internally after validated builds.
4. Add an operational dashboard with model runtimes, failure trends, test failures and freshness/lag signals where supported.
5. Build a formal release checklist based on the [PR template](docs/templates/pull-request-template.md).


---

# 06 — Quality, metadata and lineage


**Status:** Existing registers, dbt/Power BI lineage and access model are Current. Documentation and testing minimums are Proposed.

## 6.1 What quality means

Quality is not simply whether the SQL executes. A trusted dataset should be understandable, appropriately complete, timely, consistent with its business definition and controlled for its consumers.

**Proposed model assurance dimensions:**

| Dimension | Example check |
| --- | --- |
| Identity / uniqueness | No duplicate grain keys |
| Completeness | Required keys and reporting fields are non-null |
| Validity | Country codes or status values belong to approved domains |
| Referential integrity | Child entity keys resolve to their governed parents |
| Reconciliation | Aggregate totals match agreed Silver/source controls |
| Temporal correctness | SCD2 intervals do not overlap; one current version |
| Freshness | Data arrives within its documented cadence (where measurable) |
| Contract integrity | Published columns, types, grain and classifications are reviewed |

Use source-specific tolerances approved by data owners; do not create noisy global thresholds without a real business requirement.

## 6.2 Metadata source of truth — Current

- **Source and data products:** the **Data Source Register** and **Data Product Register** document domain, technical and business ownership, descriptions, sensitivity and access controls.
- **dbt model lineage:** `manifest.json` describes dependencies within staging, intermediate, Silver and Gold.
- **Downstream BI:** Power BI lineage supplies the consumption side, including reports/semantic models within its coverage.
- **Data models:** recorded within the Data Product Register; there is no separate model register.

**Proposed:** Reference consistent register identifiers in dbt model `config.meta` where practical; avoid copying inconsistent owner names and business definitions to many places.

## 6.3 Minimum model documentation — Proposed

For every **new or substantially changed Silver/Gold** model, require:

- A non-generic, business-readable `description` explaining purpose.
- Explicit **grain** and business/domain owner.
- Source/upstream lineage through dbt references.
- Description of important filtering, history or aggregation logic.
- Meaningful descriptions for identifiers, dates, amounts and status fields.
- A declared list of intended consumers, or a link to the register.
- Applicable data tests (at least not-null/unique for required grain keys, unless not appropriate).
- Sensitivity/classification and access implications.

Use [model_properties.yml](docs/templates/model_properties.yml) as a starting template.

### Example with metadata and tests

```yaml
version: 2
models:
  - name: gld_example_trade_summary
    description: >
      Illustrative annual trade summary: one row per country_code and calendar_year.
      The metric is derived from governed Silver records.
    config:
      meta:
        domain: trade
        business_owner: "REPLACE_WITH_APPROVED_OWNER"
        technical_owner: analytics_engineering
        grain: "country_code + calendar_year"
        classification: internal
        consumers: "REPLACE_WITH_REGISTER_LINK_OR_ID"
    columns:
      - name: country_code
        description: "Country code used to group trade totals."
        data_tests:
          - not_null
      - name: calendar_year
        description: "Calendar year used for aggregation."
        data_tests:
          - not_null
```

A composite grain requires a **composite uniqueness test**; a `unique` test on either single column would be incorrect. Implement a supported package or a singular SQL test with the relevant `(country_code, calendar_year)` grouping.

## 6.4 Write meaningful dbt tests

**Built-in tests:** `not_null`, `unique`, `accepted_values`, `relationships`. These validate assumptions; they do not prove a complete business transformation is correct.

Example singular SQL test (`tests/assert_no_duplicate_trade_grain.sql`):

```sql
select
    country_code,
    calendar_year
from {{ ref('gld_example_trade_summary') }}
group by country_code, calendar_year
having count(*) > 1
```

A dbt SQL data test should return **zero rows** when the assertion passes. Include non-trivial reconciliation and SCD2 tests where appropriate. Validate every selected package/adapter test against Synapse Dedicated SQL Pool before relying on it in production.

## 6.5 Understand the lineage of a change

A workflow for impact assessment:

1. Locate the model in dbt Docs or use `dbt ls --select "model_name+"`.
2. Inspect its immediate source and downstream model dependencies.
3. Follow dbt exposures (if defined) and Power BI lineage to semantic models, reports and apps.
4. Decide whether a schema/column change is backward compatible.
5. Identify the owner of each published contract and consult them where behaviour changes.
6. Document the findings in the pull request.

**Proposed:** Create dbt **exposures** for critical Power BI reports and application outputs; maintain them or generate verified references. Exposures supplement rather than replace Power BI's own lineage.

## 6.6 Generate and publish dbt documentation

On dbt v1.12, run:

```bash
dbt docs generate
dbt docs serve
```

`docs generate` produces documentation assets and catalog/manifest artifacts in the project target directory. Hosting them centrally on an approved, access-controlled internal service is **Proposed**, not yet a confirmed TDI feature. Never publish sensitive project metadata to an unapproved public site.

## 6.7 Access and protection

The Director of Data Operations manages domain schema access through Entra ID access packages, with approval controls. A Silver domain permission can grant downstream Gold/subdomain permission for the same domain: **a newly published Silver or Gold column can therefore widen exposure**. Validate classification and consumer needs before release, and do not put credentials or personal identifiers into examples, tests or diagnostic logs.

## 6.8 Suggested adoption metric — Proposed

Report at least monthly: share of production Silver/Gold models with documented purpose, grain, owner, key columns, test coverage and identified consumers. Use a clearly defined denominator and distinguish *presence* from *reviewed quality* of metadata; completion percentage alone is not evidence that data is trustworthy.


---

# 07 — Operations, performance and troubleshooting


**Status:** TDI technology and orchestration are Current. Troubleshooting procedures and recommendations are Proposed and must be checked against approved operational runbooks.

## 7.1 First five questions for a failed run

1. **Where did it fail?** Source integration, Landing, Bronze Spark, append load, Azure DevOps setup, dbt model or data test?
2. **When?** Which production run, schedule, source, deployment and model version?
3. **What changed?** Incoming source shape/volume, SQL, YAML, package, credentials or permissions?
4. **What is affected?** One model, downstream Silver/Gold, data access or a published consumer?
5. **Can it be safely retried?** Check append/idempotency and history semantics before replaying a source or model.

Do not repeatedly re-run a failed production load without understanding whether it duplicates append-only data.

## 7.2 Evidence to collect

| Evidence | Why it matters |
| --- | --- |
| Azure DevOps pipeline run ID, start/end time, job/step | Distinguishes setup, selection and execution failures |
| Synapse pipeline activity/run ID | Establishes upstream ingestion/trigger state |
| dbt invocation and selected target/selector | Confirms what actually ran |
| `target/run_results.json` | Node outcomes, execution times and failures |
| `target/manifest.json` | Model configuration, compiled graph, resource metadata |
| Relevant dbt logs | Compiler, adapter and warehouse errors |
| SQL pool request/query IDs and workload metrics | Diagnoses waits, memory, skew and data movement |
| Row counts / key counts / test results | Determines whether a failure affected data correctness |

Store artifacts and logs only in approved locations and redact sensitive values.

## 7.3 Troubleshooting playbook

| Symptom | Likely area to investigate | First safe action |
| --- | --- | --- |
| Missing rows from a source | Source delivery / Landing / Bronze / `_SRC` | Compare last received source file/change window and Bronze load status |
| `source()` or `ref()` compilation error | dbt declarations or model rename | Run `dbt parse`, inspect model names and YAML definitions |
| Cannot connect / permission denied | `profiles.yml`, Entra access, SQL pool availability | Verify target and access package; use `dbt debug` |
| Failed data test | Source change or transformation regression | Query failing rows in dev/approved read-only environment |
| Unexpected duplicate current records | SCD2/dedup ordering, repeat deliveries | Inspect `(entity_id, versionnumber)` and valid-interval construction |
| Model is slow | Expensive view chain, join movement, table distribution, data size | Inspect query plan, row counts and upstream materialisations |
| Columnstore out-of-memory | Wide columns, memory grant, resource class, CCI | Test alternate table/index/load strategy; do not blindly raise DWU |
| Gold table changed but report stale | Power BI semantic refresh/caching/lineage | Confirm Gold data first, then semantic model refresh and report dependencies |
| Schedule skipped a new model | Selector membership / tag/path criteria | Compare actual selector definitions and `dbt ls --selector` output |

## 7.4 Synapse performance rules of thumb

- **Distribution matters.** Use `HASH` where stable large-table joins support it and skew is acceptable; `ROUND_ROBIN` is often suitable for fast staging but can increase data movement; `REPLICATE` can help small dimensions.
- **Columnstore is not universal.** Wide tables and memory-constrained builds can fail during CCI creation or create poor rowgroups. Assess table width, cardinality, memory class and indexing strategy.
- **Too many tiny partitions hurt.** Dedicated SQL Pool distributes data across compute distributions; overpartitioning can leave sparse columnstore rowgroups.
- **Materialise expensive joins when justified.** A small view may be preferable to a persisted table, but deeply nested view chains can create costly repeated work.
- **Profile before changing compute.** Compare prior durations and query statistics; avoid guessing that higher DWUs alone solve a bad distribution or data-model design.
- **Avoid unnecessary wide scans.** Select needed columns instead of repeatedly scanning large, wide Dynamics 365 tables.

**Operational precedent:** The team has encountered memory pressure trying to construct clustered columnstore tables in a large Synapse workload. This is a design consideration, not a blanket ban on CCI.

## 7.5 Operational health dashboard — Proposed

A useful dbt observability dashboard should report:

| Measure | How to derive/interpret |
| --- | --- |
| Pipeline success rate | Counts of succeeded, failed and cancelled executions over time |
| Build duration | End-to-end and per model; compare with baseline and schedule |
| Slowest models | Per-node execution-time trend from run results |
| Test failures | Per test, model, domain, severity and first observed date |
| Last successful run | Time of last successful materialisation per critical node |
| Source staleness | Source-specific arrival timestamp/availability, where captured |
| Data volume | Row count and data size by domain / product (data steward view) |
| Lineage impact | Models and reports dependent on a failed or late-running model |
| Runtime hotspots | Heavy joins, source reprocessing, data movement, resource waits |

`manifest.json` is the dbt graph/config source; `run_results.json` captures run outcomes. Additional history storage is needed for trends; a single run artifact does not provide complete longitudinal observability. Verify the semantics of run status and timings before calculating metrics.

## 7.6 Recovery playbook — Proposed outline

**If the Bronze/source layer is wrong:** stop downstream promotion where supported, contact Data Engineering, identify source and batch scope, assess append/idempotency, repair/backfill from controlled source data, then replay and reconcile the downstream dependency chain.

**If Silver/Gold logic is wrong:** isolate affected data products, identify last good code and known-good data, decide whether a rebuild from Bronze/`_SRC` is safe, obtain required release approval, deploy via CI/CD, rerun affected models/tests and validate consumers.

**If output schema changed:** investigate whether dependent SQL views, semantic models, Excel connections or applications need updates. Rename/swap operations can invalidate external references even when dbt itself compiles.

## 7.7 Incident note template

```text
Incident reference:
Start / detected / recovered (timezone):
Affected source(s), model(s), schema(s) and consumers:
What failed, including run ID and error excerpt:
Current data correctness assessment:
Immediate containment:
Root cause and evidence:
Replay/backfill or rollback plan:
Approvals and communications:
Validation evidence and close-out owner:
Follow-up prevention action:
```

The exact incident-management system and escalation contacts should be linked here after internal validation; do not invent them.


---

# 08 — New engineer onboarding


**Goal:** An engineer can explain the TDI data path, trace one real model end-to-end and submit a small, tested dbt pull request without relying on undocumented tribal knowledge.

## Before access is granted

The relevant manager/owner confirms current onboarding and least-privilege procedures. Never ask an engineer to use someone else's credentials or a shared developer account.

## Days 1–2: Learn the data flow

**Task A — Explain the architecture in your own words.**

Starting with a Dynamics 365 record, describe:

1. Synapse Link's route through the ACE data lake.
2. ADF copying changes into EDP Landing.
3. The YAML-configured Synapse Spark Bronze pipeline.
4. Delta/Parquet Bronze outputs and append load into Dedicated SQL Pool `_SRC`.
5. dbt's staging/intermediate, Silver and Gold transformations.
6. A Power BI semantic model consuming the output.

**Definition of done:** You can show the technical boundary between Data Engineering and Analytics Engineering and identify who approves production changes to each area.

## Days 2–3: Learn an actual model

**Task B — Choose one actively maintained Gold model with your mentor.**

Complete the following discovery worksheet:

| Question | Your finding |
| --- | --- |
| Model name/path | |
| Purpose and business owner | |
| Warehouse schema and relation | |
| Grain and key(s) | |
| Upstream source/models | |
| Intermediate/Silver dependencies | |
| Downstream dbt models | |
| Power BI/app consumers | |
| Materialisation and expected runtime | |
| Tests and known data caveats | |
| Production selector/schedule | |

Suggested commands:

```bash
dbt --version
dbt debug
dbt ls --resource-type model
dbt ls --select "+MODEL_NAME"
dbt ls --select "MODEL_NAME+"
dbt compile --select "MODEL_NAME"
```

Replace `MODEL_NAME` with a real node and work in an approved environment. Read model SQL and YAML; check the production pipeline's actual selectors rather than assuming every Gold model runs daily.

## Days 3–5: Make a safe first change

**Task C — Documentation plus one focused test.**

1. Find a real model with incomplete documentation or an obvious missing quality assertion.
2. Confirm the dataset grain and expected field semantics with the model owner.
3. Update its YAML description, key-column description or one supported test.
4. Run `dbt parse`, targeted `dbt test`/`dbt build` in an approved development target, and review results.
5. Populate the [PR template](docs/templates/pull-request-template.md), including downstream impact and screenshots/log excerpts if allowed.
6. Request review and follow the actual approval workflow. Do not bypass production sign-off because the change appears small.

**Definition of done:** The engineer can demonstrate the model's lineage and justify every added test.

## Week 2: Learn a transformation pattern

**Task D — Examine one of the following with a mentor:**

- A source staging model with source-specific renaming and data type harmonisation.
- A version-based Dynamics 365 SCD2 model using `(entity_id, versionnumber)`.
- A Silver domain entity assembled from multiple sources.
- A Gold report/product aggregate with a reconciliation test.

Document the grain, source caveats, full/rebuild behaviour and data quality assertions. Review how a future source schema change would affect this model.

## Week 3: Learn production operations safely

**Task E — Walk through a previous completed pipeline run.**

Inspect the Synapse-to-DevOps trigger, seed, priority-100, priority-200 and available run artifacts. Identify one historical failure and show where the logs would reveal its cause; **do not rerun production** as an onboarding exercise.

## Graduation checklist

- [ ] Understands approved ingestion paths and medallion layers.
- [ ] Knows difference between source YAML, `dbt_project.yml` and `profiles.yml`.
- [ ] Can use `ref()`, `source()`, `dbt ls`, parse/compile/build/test safely.
- [ ] Can explain grain, history semantics and main quality checks.
- [ ] Knows actual selectors and release approvals.
- [ ] Can identify upstream data-owner vs downstream business-definition issues.
- [ ] Completed a reviewed documentation/test PR.
- [ ] Knows when to escalate performance, data quality or access concerns.

## Mentor notes

Do not require memorisation of the entire model catalogue. An engineer is ready when they **know how to find reliable answers**, can make an appropriately scoped change and know when human approval is required.


---

# 09 — Quick reference and glossary


## 9.1 Common dbt commands (dbt 1.12)

| Command | Use |
| --- | --- |
| `dbt --version` | Show installed dbt and adapter versions |
| `dbt debug` | Check target connection/profile |
| `dbt deps` | Install project dependencies where `packages.yml` / `dependencies.yml` applies |
| `dbt parse` | Parse configuration, YAML and SQL/Jinja references |
| `dbt compile --select "model_name"` | Compile a selected model without executing model materialisation |
| `dbt ls --resource-type model` | List models |
| `dbt ls --select "+model_name"` | Show selected model and its upstream parents |
| `dbt ls --select "model_name+"` | Show selected model and its downstream children |
| `dbt ls --select "path:models/silver"` | Show resources under a path (adapt to real repo) |
| `dbt build --select "model_name" --target dev` | Build selected resources and their selected tests in a verified dev target |
| `dbt test --select "model_name" --target dev` | Execute selected tests against existing relations |
| `dbt seed --target dev` | Load seed data into an approved dev target |
| `dbt docs generate` | Generate dbt 1.x documentation assets |
| `dbt docs serve` | Serve generated docs locally |

**Safety:** Always check the target and size the selector using `dbt ls` before a costly execution. The table uses **illustrative** model names and assumes a target called `dev` only for demonstration.

## 9.2 What does the plus sign mean?

```bash
+model_name      # model and ancestors (upstream)
model_name+      # model and descendants (downstream)
+model_name+     # both upstream and downstream, plus the model
```

The selection graph only sees dependencies declared to dbt; it will not automatically see every Power BI report or other external consumer.

## 9.3 Technical glossary

| Term | Meaning in TDI |
| --- | --- |
| Landing | ADLS Gen2 intake for approved source routes |
| Bronze | Source-standardised structured Parquet/Delta outputs produced by Synapse Spark |
| `_SRC` | Source-facing tables in Dedicated SQL Pool after append loads |
| Staging | Source-near dbt SQL preparations |
| Intermediate | Reusable joins, deduplication, history and transformations |
| Silver | Reusable, governed domain tables (`SLV_<DOMAIN>`) |
| Gold | Consumption-ready data products (`GLD_<DOMAIN>` / subdomains) |
| Grain | Business meaning of one row |
| SCD2 | Slowly Changing Dimension Type 2; keeps historical versions with validity periods |
| `entity_id` | Generic Dynamics 365 entity identifier projected into source tables |
| `versionnumber` | Dynamics source change/version key used to signal new history version |
| `ref()` | Declares a dbt dependency on another model |
| `source()` | Declares a dbt dependency on a registered source table |
| `manifest.json` | Machine-readable dbt graph and node metadata |
| `run_results.json` | Outcomes for nodes invoked by a particular dbt command |
| `dbt_project.yml` | dbt project configuration |
| `profiles.yml` | dbt connection/target configuration |
| Source metadata YAML | File controlling a specific source's Spark Bronze preprocessing |
| Exposure | dbt description of a downstream dashboard/application and its model dependencies |
| CTAS | `CREATE TABLE AS SELECT`, a SQL pool loading/rebuild pattern |
| CCI | Clustered columnstore index; performance depends on rowgroup quality and available memory |
| DWU | Data Warehouse Unit, a Synapse Dedicated SQL Pool compute sizing measure |

## 9.4 Documentation and authoritative references

Use version-specific dbt pages for the team's **1.12** runtime; the latest dbt docs may also describe version 2 features that do not apply.

- dbt 1.12 data tests: https://docs.getdbt.com/docs/build/data-tests?version=1.12
- dbt 1.12 model configurations: https://docs.getdbt.com/reference/define-configs?version=1.12
- dbt graph selectors: https://docs.getdbt.com/reference/node-selection/graph-operators
- dbt metadata (`meta`): https://docs.getdbt.com/reference/resource-configs/meta
- dbt documentation: https://docs.getdbt.com/docs/build/documentation
- Synapse dedicated SQL pool table design: https://learn.microsoft.com/en-us/azure/synapse-analytics/sql-data-warehouse/sql-data-warehouse-tables-overview
- Synapse distribution design: https://learn.microsoft.com/en-us/azure/sql-data-warehouse/sql-data-warehouse-tables-distribute
- Synapse columnstore memory optimisation: https://learn.microsoft.com/en-us/azure/synapse-analytics/sql-data-warehouse/sql-data-warehouse-memory-optimizations-for-columnstore-compression
- Synapse table rename limitations: https://learn.microsoft.com/en-us/sql/t-sql/statements/rename-transact-sql?view=azure-sqldw-latest

## 9.5 Local project references to add after validation

| Link to add | Owner |
| --- | --- |
| TDI Azure DevOps project/repository URL | Lead Data Engineer |
| Current `selectors.yml` and scheduled pipeline YAML | Lead Data Engineer |
| Approved development environment and connection instructions | Lead Data Engineer |
| Data Source Register and Data Product Register | Data Operations |
| Entra access package request/approval guide | Data Operations |
| Power BI lineage entry point | BI / analytics platform owner |
| Approved incident and escalation runbook | Platform/operations owner |
| Internal dbt Docs URL (when implemented) | Data Operations |

No internal URLs are invented in this draft.


---

# Appendix — Copyable templates


## decision-record-template.md

# Engineering decision: <descriptive title>

**Status:** Proposed / Approved / Superseded  
**Owner:** <role>  
**Date:** <YYYY-MM-DD>  
**Decision scope:** <source / Bronze / warehouse / dbt / Silver / Gold / BI>

## Context and problem

What constraint or recurring issue motivates the decision? Include relevant source semantics, operational evidence and impacted consumers.

## Decision

Describe what will be done, where and when. Show an example or precise configuration if useful.

## Alternatives considered

| Alternative | Advantages | Trade-offs |
| --- | --- | --- |
| A | | |
| B | | |

## Consequences and controls

- Security / governance implications:
- Runtime, compute, storage or maintenance impact:
- Backfill and recovery approach:
- Required documentation, tests, observability:
- Sign-off required and approval reference:

## Validation and review date

How will the team establish whether this decision works? When should it be revisited?


## model-design-note.md

# Model design note: <dbt node name>

**Status:** Draft / Approved  
**Domain:** <domain>  
**Technical owner:** <role/team>  
**Business owner:** <approved owner>  
**Target layer/schema:** <Silver / Gold and intended schema>

## Business purpose

What does this model enable, and who uses it?

## Row grain and keys

- One row represents:
- Natural/business key(s):
- Technical key(s), if any:
- Current or historical view:

## Inputs and processing

- Direct upstream dbt dependencies:
- Source systems / source caveats:
- Main transformations, filters, joins and calculations:
- Handling of duplicates, late arrival and source versioning:
- Target materialisation and reasons:
- Distribution/index considerations for Synapse:

## Contract and quality

- Published columns, units and definitions:
- Mandatory fields and quality checks:
- Reconciliation approach:
- Refresh expectation / selector coverage:
- Sensitive data, classification and access implications:

## Dependencies and delivery

- Downstream models and external Power BI/application consumers:
- Required backfill, migration or consumer communication:
- Runtime baseline/expected change:
- Production approval required:
- Recovery plan:


## model_properties.yml

```yaml
# TEMPLATE ONLY — adapt model, owner, domain, sensitivity and fields.
# Copy relevant contents to the appropriate model properties YAML.
version: 2
models:
  - name: slv_example_entity
    description: >
      Illustrative Silver dataset. One row per entity_id representing the
      current version of a governed business entity.
    config:
      meta:
        domain: REPLACE_WITH_DOMAIN
        business_owner: REPLACE_WITH_APPROVED_BUSINESS_OWNER
        technical_owner: analytics_engineering
        classification: REPLACE_WITH_APPROVED_CLASSIFICATION
        grain: one row per entity_id
        consumers: REPLACE_WITH_DATA_PRODUCT_REGISTER_REFERENCE
        history_semantics: current_state
    columns:
      - name: entity_id
        description: Stable identifier of the business entity.
        data_tests:
          - not_null
          - unique
      - name: source_modified_at
        description: Source-reported modification timestamp, if reliable.

```

## pull-request-template.md

# Pull request: <short change description>

**Work item:** <link>  
**Author:** <name/team>  
**Affected layers:** <staging / intermediate / Silver / Gold / Bronze / platform>  
**Environments validated:** <approved development target(s)>

## Intent and scope

- Why this change is needed:
- Models / schemas / materialisations affected:
- Grain, keys or business definition changed? If yes, describe:
- Data classification or schema access changed? If yes, describe:
- Does this add a **new Silver table**? **Yes / No**

## Impact assessment

- Upstream sources and models:
- Downstream dbt models:
- Power BI semantic models / reports / application consumers:
- Change compatibility and required stakeholder communications:

## Evidence

- Commands/tests run (target and selector):
- Results and known exceptions:
- Row count / duplicate key / reconciliation checks:
- Runtime/warehouse cost impact (if material):
- History/backfill/replay considerations:

## Release and recovery

- Selector/schedule coverage verified:
- Production deployment and follow-up verification owner:
- Rollback or rebuild approach:
- Linked handbook/metadata changes:

## Required approval

- [ ] Analytics Engineering code review complete.
- [ ] **Director of Data Operations final sign-off for Silver/Gold change** captured.
- [ ] **Director approval of new Silver table**, if applicable, captured before publish.
- [ ] Lead Data Engineer sign-off for Landing/Bronze/platform/CI/CD change, if applicable.
- [ ] Data/business owner consulted if contract, definition or classification changed.
- [ ] Current Azure DevOps branch and release policies satisfied.
