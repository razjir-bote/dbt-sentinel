# TDI Engineering Handbook

**Trusted Data Initiative (TDI) — Enterprise Data Platform (EDP)**  
**Primary audience:** Analytics Engineers, Data Engineers, technical reviewers and support staff  
**Working baseline:** dbt 1.12.6 and Azure Synapse Dedicated SQL Pool (database `edp`)  
**Document status:** Draft for team validation · 16 November 2026  
**Document owner:** Director of Data Operations

> **Read this first.** This handbook combines **confirmed TDI practices** with **proposed team standards**. Existing practices are labelled **Current**. New conventions and controls are labelled **Proposed** and should not be treated as approved production policy until reviewed. Example models and commands are illustrative; validate names, selectors, configurations and permissions against the live repository.

## Why this handbook exists

An engineer should be able to determine: (1) what a dataset does, (2) where it comes from, (3) what depends on it, (4) how to change it, and (5) how it reaches production. Code, dbt metadata and this handbook should agree. If they do not, raise the discrepancy and correct the authoritative source.

## Navigation

Prefer one file? Read [the complete handbook](TDI_ENGINEERING_HANDBOOK_COMPLETE.md).

| Guide | Read when you need to… |
| --- | --- |
| [01 — Architecture and data flow](docs/01-architecture-and-data-flow.md) | Understand the EDP, ingestion paths, ownership boundaries and medallion layers |
| [02 — Project structure and model conventions](docs/02-project-structure-and-conventions.md) | Find or design a dbt model, choose its materialisation and schema |
| [03 — Development workflow](docs/03-development-workflow.md) | Make a safe change from branch to pull request |
| [04 — Transformation patterns](docs/04-transformation-patterns.md) | Apply source staging, deduplication, SCD2 and domain modelling patterns |
| [05 — Orchestration and release governance](docs/05-orchestration-and-release-governance.md) | Understand selectors, jobs, approvals and rollback |
| [06 — Quality, metadata and lineage](docs/06-quality-metadata-and-lineage.md) | Write tests, document models and assess downstream impact |
| [07 — Operations, performance and troubleshooting](docs/07-operations-performance-and-troubleshooting.md) | Diagnose dbt failures and Synapse performance problems |
| [08 — New engineer onboarding](docs/08-new-engineer-onboarding.md) | Complete a guided first change and learn the system |
| [09 — Quick reference and glossary](docs/09-quick-reference-and-glossary.md) | Find commands, terms and official documentation |

### Ready-to-use templates

- [Model metadata and test template](docs/templates/model_properties.yml) (example; replace names and fields)
- [Pull request checklist](docs/templates/pull-request-template.md)
- [Architecture/engineering decision record](docs/templates/decision-record-template.md)
- [Model design note](docs/templates/model-design-note.md)

## One-minute map

```text
Source systems / datasets / files
  ├─ iPaaS for approved API, dataset and file integrations
  ├─ ACE Dynamics 365 → Synapse Link → ACE lake → ADF copy
  └─ Manual files → EDP SharePoint → iPaaS
                      ↓
                ADLS Gen2 Landing
                      ↓
      Synapse Spark notebooks, driven by source YAML
      ZIP Preprocessor / JSON Preprocessor / Bronze Processor
                      ↓
         Bronze Parquet and Delta tables in ADLS
                      ↓  append load
               Synapse Dedicated SQL Pool
                  database: edp; `_SRC` schemas
                      ↓  Azure DevOps executes dbt
           Staging / Intermediate transformations
                      ↓
       Silver: SLV_<DOMAIN> (governed domain tables)
                      ↓
       Gold: GLD_<DOMAIN> / GLD_<SUBDOMAIN>
                      ↓
        Power BI / governed semantic models / apps
```

## First-day sequence

1. Read **01**, **02** and **05** before editing production-facing models.
2. Check your approved environment, database, schema permissions and `profiles.yml` target.
3. Run `dbt --version`, `dbt debug`, `dbt parse` and `dbt ls` in your development environment.
4. Open a real Gold model; inspect its SQL, YAML, upstream `ref()` chain and consumers.
5. Follow the [onboarding exercise](docs/08-new-engineer-onboarding.md).

## Maintaining the handbook

- Documentation changes are submitted in the same pull request as the change they explain.
- Include the documentation owner and last review date in each substantial revision.
- The **dbt manifest** is authoritative for dbt model dependencies; the **Power BI lineage view** is authoritative for downstream Power BI lineage. This handbook explains intent and process, not real-time graph state.
- **Never** commit secrets, tokens, personal information or environment credentials to Markdown, YAML or example logs.
- Decisions proposed here become standards only after the appropriate engineering approval.

## Adoption checklist (for the lead reviewers)

- [ ] Verify actual folder names, dbt package and adapter versions, profiles and runtime targets.
- [ ] Replace illustrative selector names with the real `selectors.yml` names and schedule matrix.
- [ ] Confirm schema naming, tags, materialisation overrides, data classifications and owners.
- [ ] Confirm current PR branch policies and test scope; publish links to internal tooling.
- [ ] Approve or revise the **Proposed** conventions before making them mandatory.

