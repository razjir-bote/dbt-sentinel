# 03 — Development workflow

[← Handbook home](../README.md) · [← Conventions](02-project-structure-and-conventions.md) · [Next: patterns →](04-transformation-patterns.md)

**Status:** Approved production sign-off is Current; command sequence and working checklist are **Proposed** defaults. Validate actual credentials, target names and branch policies.

## 3.1 Before starting

1. Confirm a work item and expected outcome with the dataset/business owner.
2. Locate the model and read its YAML description, SQL, tests and upstream dependencies.
3. Identify all direct downstream dbt nodes and Power BI/application consumers.
4. Record whether you are changing data structure, business meaning, historical treatment, refresh logic or access exposure.
5. Confirm your development target is isolated from production and you have access to only the schemas needed.

### Safe environment checks

```bash
dbt --version
# Shows installed dbt version and adapter version.

dbt debug
# Validates local configuration and the currently selected connection target.

dbt parse
# Validates project parsing without running model SQL.

dbt ls --resource-type model
# Shows model inventory.
```

Use your team's approved `--profiles-dir`, `--target`, `--project-dir` and environment variables where applicable. Check the target printed by `dbt debug`; **do not accidentally execute builds against production**.

## 3.2 Discover dependencies and model impact

```bash
# Model and everything it depends on:
dbt ls --select "+slv_trade_transactions"

# Model and everything downstream:
dbt ls --select "slv_trade_transactions+"

# Specific resource metadata / structured output:
dbt ls --select "slv_trade_transactions" --output json

# Show a planned selection without running SQL:
dbt ls --select "path:models/silver/trade"
```

These names and paths are examples. `+` includes the selected resource itself. Separate *dbt graph impact* from *non-dbt consumers* (Power BI semantic models, reports and applications).

## 3.3 Branch, design, implement

**Proposed workflow:**

1. Create a branch linked to a work item under current Azure DevOps policy.
2. Fill out the [model design note](templates/model-design-note.md) for a new or materially changed model.
3. Make the narrowest SQL change consistent with the domain definition.
4. Update YAML descriptions, keys, ownership metadata and relevant tests **in the same commit**.
5. Update the handbook or a decision record if the change adds/replaces a pattern.
6. Document any source caveats, particularly duplicate, late-arrival and history behaviour.

Avoid changing production source tables by hand to force a passing dbt build.

## 3.4 Validate locally/in development

```bash
# Parse/compile first:
dbt parse
dbt compile --select "slv_trade_transactions"

# Execute one model and its directly selected tests in a dev target:
dbt build --select "slv_trade_transactions" --target dev

# Run the selected model plus upstream parents when a clean dev environment requires them:
dbt build --select "+slv_trade_transactions" --target dev

# Test an existing selected model without rebuilding it:
dbt test --select "slv_trade_transactions" --target dev
```

**Do not assume `dev` exists**: replace it with the target name verified in `profiles.yml`. Building upstream dependencies can be costly and may touch large sources. Estimate scope with `dbt ls` before any broad selection.

### Development checks

- A model's row grain is consistent with its design note.
- Duplicate keys and unexpected `null` values are checked.
- A sample of transformed records agrees with its upstream source.
- History rules handle multiple versions, same-version duplicates and late arrival.
- Row counts, runtime and data movement are reasonable for Synapse.
- Tests do not accidentally require production-only schemas or credentials.
- Existing dependent models still compile and pass representative regression checks.

## 3.5 Pull request checklist

Copy the [PR template](templates/pull-request-template.md). The description must include:

- Problem and change summary, including SQL and metadata changes.
- **Model(s), schema(s), grain, contract and ownership**.
- Impacted downstream models, reports/applications and access classification.
- Tests run, target, results and any required backfill.
- Performance evidence when large datasets are affected.
- An explicit statement if this creates a **new Silver table** (Director sign-off required).
- Recovery/rollback approach and an owner for validation after deployment.

## 3.6 Review and promote

Analytics engineers implement Silver/Gold changes; the **Director of Data Operations provides final production sign-off on these layers**. The **Lead Data Engineer** signs off production changes for Landing/Bronze/platform/CI/CD. A change involving both boundaries should have both relevant reviewers.

Follow current Azure DevOps build, test, release and approval processes. A successful local run does **not** authorise a production deployment. Approved CI/CD should be the route to publish production dbt changes.

## 3.7 After the release

1. Confirm the intended models ran in the correct environment.
2. Inspect test results, counts, runtime and dependency impacts.
3. Check sample data and critical Power BI/application consumption paths.
4. Record any regression, recovery action or follow-up work item.
5. Refresh published dbt documentation (when implemented) and relevant data product metadata.

For routine low-risk changes, the number of manual checkpoints can be reduced later through approved automation; do not skip existing authorisation requirements.
