# 08 — New engineer onboarding

[← Handbook home](../README.md) · [← Operations](07-operations-performance-and-troubleshooting.md) · [Next: reference →](09-quick-reference-and-glossary.md)

**Goal:** An engineer can explain the TDI data path, trace one real model end-to-end and submit a small, tested dbt pull request without relying on undocumented tribal knowledge.

## Before access is granted

The relevant manager/owner confirms current onboarding and least-privilege procedures. Never ask an engineer to use someone else's credentials or a shared developer account.

## Days 1–2: Learn the data flow

**Task A — Explain the architecture in your own words.**

Starting with a Dynamics 365 record, describe:

1. Synapse Link's route through the ACE data lake.
2. ADF copying changes into EDP Landing.
3. The YAML-configured Synapse Spark Bronze pipeline.
4. Delta/Parquet Bronze outputs and append load into Dedicated SQL Pool `_SRC`.
5. dbt's staging/intermediate, Silver and Gold transformations.
6. A Power BI semantic model consuming the output.

**Definition of done:** You can show the technical boundary between Data Engineering and Analytics Engineering and identify who approves production changes to each area.

## Days 2–3: Learn an actual model

**Task B — Choose one actively maintained Gold model with your mentor.**

Complete the following discovery worksheet:

| Question | Your finding |
| --- | --- |
| Model name/path | |
| Purpose and business owner | |
| Warehouse schema and relation | |
| Grain and key(s) | |
| Upstream source/models | |
| Intermediate/Silver dependencies | |
| Downstream dbt models | |
| Power BI/app consumers | |
| Materialisation and expected runtime | |
| Tests and known data caveats | |
| Production selector/schedule | |

Suggested commands:

```bash
dbt --version
dbt debug
dbt ls --resource-type model
dbt ls --select "+MODEL_NAME"
dbt ls --select "MODEL_NAME+"
dbt compile --select "MODEL_NAME"
```

Replace `MODEL_NAME` with a real node and work in an approved environment. Read model SQL and YAML; check the production pipeline's actual selectors rather than assuming every Gold model runs daily.

## Days 3–5: Make a safe first change

**Task C — Documentation plus one focused test.**

1. Find a real model with incomplete documentation or an obvious missing quality assertion.
2. Confirm the dataset grain and expected field semantics with the model owner.
3. Update its YAML description, key-column description or one supported test.
4. Run `dbt parse`, targeted `dbt test`/`dbt build` in an approved development target, and review results.
5. Populate the [PR template](templates/pull-request-template.md), including downstream impact and screenshots/log excerpts if allowed.
6. Request review and follow the actual approval workflow. Do not bypass production sign-off because the change appears small.

**Definition of done:** The engineer can demonstrate the model's lineage and justify every added test.

## Week 2: Learn a transformation pattern

**Task D — Examine one of the following with a mentor:**

- A source staging model with source-specific renaming and data type harmonisation.
- A version-based Dynamics 365 SCD2 model using `(entity_id, versionnumber)`.
- A Silver domain entity assembled from multiple sources.
- A Gold report/product aggregate with a reconciliation test.

Document the grain, source caveats, full/rebuild behaviour and data quality assertions. Review how a future source schema change would affect this model.

## Week 3: Learn production operations safely

**Task E — Walk through a previous completed pipeline run.**

Inspect the Synapse-to-DevOps trigger, seed, priority-100, priority-200 and available run artifacts. Identify one historical failure and show where the logs would reveal its cause; **do not rerun production** as an onboarding exercise.

## Graduation checklist

- [ ] Understands approved ingestion paths and medallion layers.
- [ ] Knows difference between source YAML, `dbt_project.yml` and `profiles.yml`.
- [ ] Can use `ref()`, `source()`, `dbt ls`, parse/compile/build/test safely.
- [ ] Can explain grain, history semantics and main quality checks.
- [ ] Knows actual selectors and release approvals.
- [ ] Can identify upstream data-owner vs downstream business-definition issues.
- [ ] Completed a reviewed documentation/test PR.
- [ ] Knows when to escalate performance, data quality or access concerns.

## Mentor notes

Do not require memorisation of the entire model catalogue. An engineer is ready when they **know how to find reliable answers**, can make an appropriately scoped change and know when human approval is required.
