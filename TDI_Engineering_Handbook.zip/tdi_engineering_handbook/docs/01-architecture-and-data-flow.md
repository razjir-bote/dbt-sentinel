# 01 — Architecture and data flow

[← Handbook home](../README.md) · [Next: project conventions →](02-project-structure-and-conventions.md)

**Status:** Current architecture, except where marked Proposed. **Scope:** Data movement and responsibilities across the EDP.

## 1.1 System at a glance

TDI operates an Azure enterprise data platform with a medallion architecture. Raw material arrives in **ADLS Gen2 Landing**. **Synapse Spark** transforms that material into structured **Bronze Parquet files and Delta tables**. Bronze data is **append-loaded** into the Synapse Dedicated SQL Pool database `edp`, in source-facing `_SRC` schemas. **dbt**, executed by **Azure DevOps**, transforms data through staging and intermediate logic into domain-specific **Silver** and **Gold** datasets. Consumers include Power BI and planned products such as DataThing and Go Global Toolkit.

The boundary matters: changes to the upstream ingestion/Bronze implementation are **Data Engineering** work; downstream Silver and Gold model changes are **Analytics Engineering** work. Platform-level changes can span both teams and must have joint review.

## 1.2 Approved ingestion routes — Current

| Route | Flow | Key point |
| --- | --- | --- |
| Standard source integration | API / dataset / file → integration designed with Integration Architect → iPaaS → Landing | Approved route for routine integrations |
| ACE Dynamics 365 | Dynamics 365 → Synapse Link → ACE lake → Azure Data Factory copy → Landing | Broad Dynamics table coverage; data is often wide and change-appended |
| Manual upload | File → EDP SharePoint → iPaaS integration → Landing | Avoid direct, unmanaged files in downstream SQL schemas |

All three routes converge on the same Landing → Bronze processing framework.

## 1.3 Bronze processing — Current

Synapse pipelines orchestrate PySpark notebooks, including:

1. **ZIP Preprocessor** — prepares compressed files where relevant.
2. **JSON Preprocessor** — prepares JSON data where relevant.
3. **Bronze Processor** — converts landed records to standardised tabular data.

A **source-specific YAML metadata profile** drives the source processing rules. The Bronze process outputs Parquet and Delta representations, after which changes are appended to Dedicated SQL Pool source tables. Confirm individual source handling and append/idempotency rules with the Data Engineering owner; do not assume every source has the same delivery frequency or change semantics.

### Three YAML concepts — do not confuse them

| File/definition | Purpose | Primary owner |
| --- | --- | --- |
| **Source YAML metadata profile** | Defines source-specific Landing/Bronze processing behaviour | Data Engineering |
| **`dbt_project.yml`** | Defines dbt project structure, materialisation defaults, model paths and configuration | Analytics Engineering, with platform oversight |
| **`profiles.yml`** | Defines dbt connection targets and credentials/secret references | Platform/Data Engineering for supported CI/CD setup; developers maintain authorised local configuration |

Never copy a production credential into a source file to simplify development.

## 1.4 Synapse Dedicated SQL Pool — Current

- Logical warehouse database: **`edp`**.
- Source-facing schemas: **`_SRC`** source tables populated after Bronze. Verify exact schema names in the live warehouse.
- Silver schemas: for example, **`SLV_TRADE`**, **`SLV_PEOPLE`**.
- Gold schemas: for example, **`GLD_TRADE`**, **`GLD_PEOPLE`**, and narrower subdomains such as **`GLD_TRADE_DEFENSE`**.
- The current pipeline builds many staging models as views; some use tables for performance. Intermediate (`int`) models are generally views, with table exceptions. Silver marts are tables. Gold marts are generally tables, with a small number of views.

These are **current tendencies**, not blanket authorisation to override a model's production config.

## 1.5 Access and consumption — Current

Access is managed through Entra ID identity/access packages. Access to a domain schema requires relevant approval; the Director of Data Operations manages schema access. **Silver domain access implies access to Gold/subdomain data for that domain** under the current entitlement structure. Users consume governed outputs primarily through Power BI reports and semantic models, with additional application consumers planned.

**Proposed:** A model design should record classification, business owner, domain, intended consumers and whether its outputs should be broadly visible to everyone with domain access. Test access implications before publishing sensitive new columns.

## 1.6 Engineering ownership and approval — Current

| Area | Builds/maintains | Final production sign-off |
| --- | --- | --- |
| Landing, Bronze, source YAML, Spark notebooks | Data Engineers | Lead Data Engineer |
| EDP platform and Azure DevOps ingestion / orchestration infrastructure | Data Engineers | Lead Data Engineer |
| Staging / intermediate / Silver / Gold transformation SQL | Analytics Engineers | Director of Data Operations for Silver and Gold changes |
| New Silver table | Analytics Engineers | **Explicit Director of Data Operations approval before production** |
| Cross-boundary change | Both teams | Relevant sign-offs for each affected area |

Reviews and approvals must follow the actual Azure DevOps branch policies. A code review is not automatically the same thing as business or production sign-off.

## 1.7 Key design principles — Proposed

1. **Use the right layer.** Do not encode business definitions in Bronze; do not make Gold silently reimplement source-cleaning logic.
2. **Lineage before change.** Trace `source()`/`ref()` links before modifying a shared model.
3. **Recoverability.** Keep the architecture recoverable from controlled source data and version-controlled transformations; avoid one-off manual repairs as the final state.
4. **Security by design.** Treat any new column or join as a potential change in data exposure.
5. **Separate observed facts and assumptions.** Record ambiguous source semantics, especially around late-arriving updates, deletions and history.

## 1.8 When to escalate

Escalate to Data Engineering for unexpected source file structures, Landing gaps, Bronze schema drift, broken append loads or ingestion configuration. Escalate to the Director of Data Operations for new Silver datasets, changes to published business definitions, changes in domain access/consumer impact or architectural exceptions.
