# 06 — Quality, metadata and lineage

[← Handbook home](../README.md) · [← Orchestration](05-orchestration-and-release-governance.md) · [Next: operations →](07-operations-performance-and-troubleshooting.md)

**Status:** Existing registers, dbt/Power BI lineage and access model are Current. Documentation and testing minimums are Proposed.

## 6.1 What quality means

Quality is not simply whether the SQL executes. A trusted dataset should be understandable, appropriately complete, timely, consistent with its business definition and controlled for its consumers.

**Proposed model assurance dimensions:**

| Dimension | Example check |
| --- | --- |
| Identity / uniqueness | No duplicate grain keys |
| Completeness | Required keys and reporting fields are non-null |
| Validity | Country codes or status values belong to approved domains |
| Referential integrity | Child entity keys resolve to their governed parents |
| Reconciliation | Aggregate totals match agreed Silver/source controls |
| Temporal correctness | SCD2 intervals do not overlap; one current version |
| Freshness | Data arrives within its documented cadence (where measurable) |
| Contract integrity | Published columns, types, grain and classifications are reviewed |

Use source-specific tolerances approved by data owners; do not create noisy global thresholds without a real business requirement.

## 6.2 Metadata source of truth — Current

- **Source and data products:** the **Data Source Register** and **Data Product Register** document domain, technical and business ownership, descriptions, sensitivity and access controls.
- **dbt model lineage:** `manifest.json` describes dependencies within staging, intermediate, Silver and Gold.
- **Downstream BI:** Power BI lineage supplies the consumption side, including reports/semantic models within its coverage.
- **Data models:** recorded within the Data Product Register; there is no separate model register.

**Proposed:** Reference consistent register identifiers in dbt model `config.meta` where practical; avoid copying inconsistent owner names and business definitions to many places.

## 6.3 Minimum model documentation — Proposed

For every **new or substantially changed Silver/Gold** model, require:

- A non-generic, business-readable `description` explaining purpose.
- Explicit **grain** and business/domain owner.
- Source/upstream lineage through dbt references.
- Description of important filtering, history or aggregation logic.
- Meaningful descriptions for identifiers, dates, amounts and status fields.
- A declared list of intended consumers, or a link to the register.
- Applicable data tests (at least not-null/unique for required grain keys, unless not appropriate).
- Sensitivity/classification and access implications.

Use [model_properties.yml](templates/model_properties.yml) as a starting template.

### Example with metadata and tests

```yaml
version: 2
models:
  - name: gld_example_trade_summary
    description: >
      Illustrative annual trade summary: one row per country_code and calendar_year.
      The metric is derived from governed Silver records.
    config:
      meta:
        domain: trade
        business_owner: "REPLACE_WITH_APPROVED_OWNER"
        technical_owner: analytics_engineering
        grain: "country_code + calendar_year"
        classification: internal
        consumers: "REPLACE_WITH_REGISTER_LINK_OR_ID"
    columns:
      - name: country_code
        description: "Country code used to group trade totals."
        data_tests:
          - not_null
      - name: calendar_year
        description: "Calendar year used for aggregation."
        data_tests:
          - not_null
```

A composite grain requires a **composite uniqueness test**; a `unique` test on either single column would be incorrect. Implement a supported package or a singular SQL test with the relevant `(country_code, calendar_year)` grouping.

## 6.4 Write meaningful dbt tests

**Built-in tests:** `not_null`, `unique`, `accepted_values`, `relationships`. These validate assumptions; they do not prove a complete business transformation is correct.

Example singular SQL test (`tests/assert_no_duplicate_trade_grain.sql`):

```sql
select
    country_code,
    calendar_year
from {{ ref('gld_example_trade_summary') }}
group by country_code, calendar_year
having count(*) > 1
```

A dbt SQL data test should return **zero rows** when the assertion passes. Include non-trivial reconciliation and SCD2 tests where appropriate. Validate every selected package/adapter test against Synapse Dedicated SQL Pool before relying on it in production.

## 6.5 Understand the lineage of a change

A workflow for impact assessment:

1. Locate the model in dbt Docs or use `dbt ls --select "model_name+"`.
2. Inspect its immediate source and downstream model dependencies.
3. Follow dbt exposures (if defined) and Power BI lineage to semantic models, reports and apps.
4. Decide whether a schema/column change is backward compatible.
5. Identify the owner of each published contract and consult them where behaviour changes.
6. Document the findings in the pull request.

**Proposed:** Create dbt **exposures** for critical Power BI reports and application outputs; maintain them or generate verified references. Exposures supplement rather than replace Power BI's own lineage.

## 6.6 Generate and publish dbt documentation

On dbt v1.12, run:

```bash
dbt docs generate
dbt docs serve
```

`docs generate` produces documentation assets and catalog/manifest artifacts in the project target directory. Hosting them centrally on an approved, access-controlled internal service is **Proposed**, not yet a confirmed TDI feature. Never publish sensitive project metadata to an unapproved public site.

## 6.7 Access and protection

The Director of Data Operations manages domain schema access through Entra ID access packages, with approval controls. A Silver domain permission can grant downstream Gold/subdomain permission for the same domain: **a newly published Silver or Gold column can therefore widen exposure**. Validate classification and consumer needs before release, and do not put credentials or personal identifiers into examples, tests or diagnostic logs.

## 6.8 Suggested adoption metric — Proposed

Report at least monthly: share of production Silver/Gold models with documented purpose, grain, owner, key columns, test coverage and identified consumers. Use a clearly defined denominator and distinguish *presence* from *reviewed quality* of metadata; completion percentage alone is not evidence that data is trustworthy.
