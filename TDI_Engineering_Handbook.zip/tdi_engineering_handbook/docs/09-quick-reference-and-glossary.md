# 09 — Quick reference and glossary

[← Handbook home](../README.md) · [← Onboarding](08-new-engineer-onboarding.md)

## 9.1 Common dbt commands (dbt 1.12)

| Command | Use |
| --- | --- |
| `dbt --version` | Show installed dbt and adapter versions |
| `dbt debug` | Check target connection/profile |
| `dbt deps` | Install project dependencies where `packages.yml` / `dependencies.yml` applies |
| `dbt parse` | Parse configuration, YAML and SQL/Jinja references |
| `dbt compile --select "model_name"` | Compile a selected model without executing model materialisation |
| `dbt ls --resource-type model` | List models |
| `dbt ls --select "+model_name"` | Show selected model and its upstream parents |
| `dbt ls --select "model_name+"` | Show selected model and its downstream children |
| `dbt ls --select "path:models/silver"` | Show resources under a path (adapt to real repo) |
| `dbt build --select "model_name" --target dev` | Build selected resources and their selected tests in a verified dev target |
| `dbt test --select "model_name" --target dev` | Execute selected tests against existing relations |
| `dbt seed --target dev` | Load seed data into an approved dev target |
| `dbt docs generate` | Generate dbt 1.x documentation assets |
| `dbt docs serve` | Serve generated docs locally |

**Safety:** Always check the target and size the selector using `dbt ls` before a costly execution. The table uses **illustrative** model names and assumes a target called `dev` only for demonstration.

## 9.2 What does the plus sign mean?

```bash
+model_name      # model and ancestors (upstream)
model_name+      # model and descendants (downstream)
+model_name+     # both upstream and downstream, plus the model
```

The selection graph only sees dependencies declared to dbt; it will not automatically see every Power BI report or other external consumer.

## 9.3 Technical glossary

| Term | Meaning in TDI |
| --- | --- |
| Landing | ADLS Gen2 intake for approved source routes |
| Bronze | Source-standardised structured Parquet/Delta outputs produced by Synapse Spark |
| `_SRC` | Source-facing tables in Dedicated SQL Pool after append loads |
| Staging | Source-near dbt SQL preparations |
| Intermediate | Reusable joins, deduplication, history and transformations |
| Silver | Reusable, governed domain tables (`SLV_<DOMAIN>`) |
| Gold | Consumption-ready data products (`GLD_<DOMAIN>` / subdomains) |
| Grain | Business meaning of one row |
| SCD2 | Slowly Changing Dimension Type 2; keeps historical versions with validity periods |
| `entity_id` | Generic Dynamics 365 entity identifier projected into source tables |
| `versionnumber` | Dynamics source change/version key used to signal new history version |
| `ref()` | Declares a dbt dependency on another model |
| `source()` | Declares a dbt dependency on a registered source table |
| `manifest.json` | Machine-readable dbt graph and node metadata |
| `run_results.json` | Outcomes for nodes invoked by a particular dbt command |
| `dbt_project.yml` | dbt project configuration |
| `profiles.yml` | dbt connection/target configuration |
| Source metadata YAML | File controlling a specific source's Spark Bronze preprocessing |
| Exposure | dbt description of a downstream dashboard/application and its model dependencies |
| CTAS | `CREATE TABLE AS SELECT`, a SQL pool loading/rebuild pattern |
| CCI | Clustered columnstore index; performance depends on rowgroup quality and available memory |
| DWU | Data Warehouse Unit, a Synapse Dedicated SQL Pool compute sizing measure |

## 9.4 Documentation and authoritative references

Use version-specific dbt pages for the team's **1.12** runtime; the latest dbt docs may also describe version 2 features that do not apply.

- dbt 1.12 data tests: https://docs.getdbt.com/docs/build/data-tests?version=1.12
- dbt 1.12 model configurations: https://docs.getdbt.com/reference/define-configs?version=1.12
- dbt graph selectors: https://docs.getdbt.com/reference/node-selection/graph-operators
- dbt metadata (`meta`): https://docs.getdbt.com/reference/resource-configs/meta
- dbt documentation: https://docs.getdbt.com/docs/build/documentation
- Synapse dedicated SQL pool table design: https://learn.microsoft.com/en-us/azure/synapse-analytics/sql-data-warehouse/sql-data-warehouse-tables-overview
- Synapse distribution design: https://learn.microsoft.com/en-us/azure/sql-data-warehouse/sql-data-warehouse-tables-distribute
- Synapse columnstore memory optimisation: https://learn.microsoft.com/en-us/azure/synapse-analytics/sql-data-warehouse/sql-data-warehouse-memory-optimizations-for-columnstore-compression
- Synapse table rename limitations: https://learn.microsoft.com/en-us/sql/t-sql/statements/rename-transact-sql?view=azure-sqldw-latest

## 9.5 Local project references to add after validation

| Link to add | Owner |
| --- | --- |
| TDI Azure DevOps project/repository URL | Lead Data Engineer |
| Current `selectors.yml` and scheduled pipeline YAML | Lead Data Engineer |
| Approved development environment and connection instructions | Lead Data Engineer |
| Data Source Register and Data Product Register | Data Operations |
| Entra access package request/approval guide | Data Operations |
| Power BI lineage entry point | BI / analytics platform owner |
| Approved incident and escalation runbook | Platform/operations owner |
| Internal dbt Docs URL (when implemented) | Data Operations |

No internal URLs are invented in this draft.
