# Pull request: <short change description>

**Work item:** <link>  
**Author:** <name/team>  
**Affected layers:** <staging / intermediate / Silver / Gold / Bronze / platform>  
**Environments validated:** <approved development target(s)>

## Intent and scope

- Why this change is needed:
- Models / schemas / materialisations affected:
- Grain, keys or business definition changed? If yes, describe:
- Data classification or schema access changed? If yes, describe:
- Does this add a **new Silver table**? **Yes / No**

## Impact assessment

- Upstream sources and models:
- Downstream dbt models:
- Power BI semantic models / reports / application consumers:
- Change compatibility and required stakeholder communications:

## Evidence

- Commands/tests run (target and selector):
- Results and known exceptions:
- Row count / duplicate key / reconciliation checks:
- Runtime/warehouse cost impact (if material):
- History/backfill/replay considerations:

## Release and recovery

- Selector/schedule coverage verified:
- Production deployment and follow-up verification owner:
- Rollback or rebuild approach:
- Linked handbook/metadata changes:

## Required approval

- [ ] Analytics Engineering code review complete.
- [ ] **Director of Data Operations final sign-off for Silver/Gold change** captured.
- [ ] **Director approval of new Silver table**, if applicable, captured before publish.
- [ ] Lead Data Engineer sign-off for Landing/Bronze/platform/CI/CD change, if applicable.
- [ ] Data/business owner consulted if contract, definition or classification changed.
- [ ] Current Azure DevOps branch and release policies satisfied.
