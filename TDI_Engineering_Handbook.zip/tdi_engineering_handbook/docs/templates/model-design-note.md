# Model design note: <dbt node name>

**Status:** Draft / Approved  
**Domain:** <domain>  
**Technical owner:** <role/team>  
**Business owner:** <approved owner>  
**Target layer/schema:** <Silver / Gold and intended schema>

## Business purpose

What does this model enable, and who uses it?

## Row grain and keys

- One row represents:
- Natural/business key(s):
- Technical key(s), if any:
- Current or historical view:

## Inputs and processing

- Direct upstream dbt dependencies:
- Source systems / source caveats:
- Main transformations, filters, joins and calculations:
- Handling of duplicates, late arrival and source versioning:
- Target materialisation and reasons:
- Distribution/index considerations for Synapse:

## Contract and quality

- Published columns, units and definitions:
- Mandatory fields and quality checks:
- Reconciliation approach:
- Refresh expectation / selector coverage:
- Sensitive data, classification and access implications:

## Dependencies and delivery

- Downstream models and external Power BI/application consumers:
- Required backfill, migration or consumer communication:
- Runtime baseline/expected change:
- Production approval required:
- Recovery plan:
