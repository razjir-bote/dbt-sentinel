# Engineering decision: <descriptive title>

**Status:** Proposed / Approved / Superseded  
**Owner:** <role>  
**Date:** <YYYY-MM-DD>  
**Decision scope:** <source / Bronze / warehouse / dbt / Silver / Gold / BI>

## Context and problem

What constraint or recurring issue motivates the decision? Include relevant source semantics, operational evidence and impacted consumers.

## Decision

Describe what will be done, where and when. Show an example or precise configuration if useful.

## Alternatives considered

| Alternative | Advantages | Trade-offs |
| --- | --- | --- |
| A | | |
| B | | |

## Consequences and controls

- Security / governance implications:
- Runtime, compute, storage or maintenance impact:
- Backfill and recovery approach:
- Required documentation, tests, observability:
- Sign-off required and approval reference:

## Validation and review date

How will the team establish whether this decision works? When should it be revisited?
