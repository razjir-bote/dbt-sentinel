# 02 — Project structure and model conventions

[← Handbook home](../README.md) · [← Architecture](01-architecture-and-data-flow.md) · [Next: development →](03-development-workflow.md)

**Status:** Existing materialisation and naming tendencies are Current; the recommended directory and design standards below are **Proposed** until validated with the actual repository.

## 2.1 Find your way around the project

Use `dbt ls --resource-type model` to inspect actual model names and `dbt ls --output path` to see their repository paths. The recommended logical organisation is:

```text
models/
  staging/              # source preparation, naming, type harmonisation
    ace/
    trade/
    people/
  intermediate/         # reusable logic: dedup, joins, SCD2 helpers
    trade/
    people/
  silver/               # reusable governed domain tables
    trade/
    people/
  gold/                 # curated data products, domain/subdomain
    trade/
    trade_defense/
macros/                 # reusable SQL and adapter-safe utilities
seeds/                  # small governed lookup data
snapshots/              # only if used and approved in this environment
tests/                  # singular SQL assertions
selectors.yml           # selector definitions, if present
dbt_project.yml         # model and project configuration
packages.yml           # optional installed packages
```

**Important:** Folder names and SQL file names alone do not determine warehouse schemas. `dbt_project.yml`, model-level `config()`, adapter logic and custom macros can determine the final schema and alias. Check compiled output and the actual target relation.

## 2.2 Model layers and responsibilities

| Model class | Does | Does not | Current materialisation tendency |
| --- | --- | --- | --- |
| Staging (`stg_`) | Rename columns, cast types, normalize source nulls, expose a stable source vocabulary | Apply reporting-specific business definitions | View, with performance-driven table exceptions |
| Intermediate (`int_`) | Join, deduplicate, perform history and reusable transformation logic | Become an unsupported consumer-facing contract | View, with selected tables |
| Silver (`slv_`) | Produce domain-ready, governed reusable datasets with explicit grain | Embed a report-only visual calculation | Table |
| Gold (`gld_`) | Prepare consumption-ready datasets, validated aggregates and published definitions | Become an ungoverned raw source passthrough | Mostly table; occasional view |

The prefixes are recommended conventions rather than a claim that every existing file already follows them.

## 2.3 Recommended model naming

- Use lower-case `snake_case` for dbt node names and SQL file names.
- Name models by **business concept** rather than by a temporary project or a team member.
- Prefix with `stg_`, `int_`, `slv_` or `gld_` when practical.
- Avoid names like `final`, `new`, `tmp`, `v2` or `test` in production models.
- Declare intended SQL relation names and schema mappings; do not rename deployed objects casually because downstream Power BI and SQL may depend on them.

Example: `stg_ace__account`, `int_ace__account_versions`, `slv_organisation`, `gld_trade_summary`. These are **illustrative**, not actual inventory.

## 2.4 One model, one contract

Before creating a model, write down:

1. **Purpose:** what question it answers or which shared data need it meets.
2. **Grain:** what one row represents.
3. **Keys:** natural/business keys and any technical keys.
4. **Source:** upstream source or model dependencies.
5. **History:** current-state, full-history or point-in-time semantics.
6. **Update behaviour:** full rebuild, append, incremental or slowly changing history.
7. **Consumers:** downstream models, Power BI semantic models, applications.
8. **Owner/classification:** responsible domain owner and data sensitivity.
9. **Quality rules:** what must always be true.
10. **Operational profile:** approximate row count, expected refresh, key performance risks.

Use the [model design note](templates/model-design-note.md) before adding a consequential Silver or Gold model.

## 2.5 SQL style — Proposed

```sql
with source_rows as (
    select
        entity_id,
        versionnumber,
        modifiedon
    from {{ ref('stg_ace__account') }}
),

filtered as (
    select *
    from source_rows
    where entity_id is not null
)

select
    entity_id,
    versionnumber,
    modifiedon
from filtered
```

- Use `{{ ref('model_name') }}` for dbt model dependencies and `{{ source('source_name', 'table_name') }}` for registered raw sources. Avoid hard-coded production database names in transformation SQL.
- Prefer explicitly selected columns in durable contracts over `select *` (especially with very wide Dynamics 365 data).
- Name intermediate CTEs for their intent, not `cte1` / `cte2`.
- Explain non-obvious business rules with brief comments; put the business meaning in YAML descriptions.
- Preserve deterministic deduplication and stable ordering for history processing.
- Do not assume every T-SQL feature supported by SQL Server also works in Synapse Dedicated SQL Pool.

## 2.6 Materialisation, distribution and indexing

**Current:** Staging/intermediate often use views; Silver and Gold generally persist tables.

**Proposed decision rules:**

- Choose a **view** for lightweight reusable logic where repeated execution is inexpensive.
- Choose a **table** when repeatedly recomputing complex joins, expensive transformations or consumer workloads would be costly.
- Discuss **incremental** models or custom materialisations with the lead reviewer before using them; verify the adapter's actual strategy and result under retry, duplicate records and backfills.
- For large tables, choose table **distribution** based on join keys and skew; `ROUND_ROBIN` is simple to load but can add data movement. Small lookup tables may suit `REPLICATE`; large joined facts often warrant evaluated `HASH` distribution.
- Avoid assuming a **clustered columnstore index** is always suitable. Very wide, low-row-count or memory-heavy tables may need another design. Evaluate rowgroup quality and load resources.

Document any overridden materialisation, distribution or index choice in the model design note, including measured evidence.

## 2.7 Tags and metadata — Proposed

Use tags for discovery and intentional selection; do **not** invent new production selector tags without reviewing existing `selectors.yml` / orchestration code.

Recommended *metadata keys* (not mandatory until approved): `domain`, `business_owner`, `technical_owner`, `classification`, `grain`, `consumers`, `refresh_expectation`, `maturity`.

```yaml
models:
  - name: slv_example_entity
    description: "Illustrative governed entity at one row per entity_id."
    config:
      meta:
        domain: example
        technical_owner: analytics_engineering
        classification: internal
        grain: one row per entity_id
    columns:
      - name: entity_id
        description: "Unique source identifier."
        data_tests:
          - not_null
          - unique
```

Where possible use actual register owner IDs and canonical classification values. `meta` keys are arbitrary data; dbt does not enforce your business rules without separate validations.

## 2.8 Before changing structure

Read `dbt_project.yml`, model configs, macros, existing YAML properties, job selectors and Power BI consumers. Confirm which choices are deliberate adaptations for Synapse performance. Never restructure the whole repository simply to match this proposed layout; migrate in reviewed increments with equivalent compiled relation names.
