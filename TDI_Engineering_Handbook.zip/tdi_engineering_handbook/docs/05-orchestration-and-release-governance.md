# 05 — Orchestration and release governance

[← Handbook home](../README.md) · [← Patterns](04-transformation-patterns.md) · [Next: quality →](06-quality-metadata-and-lineage.md)

**Status:** TDI orchestration and sign-off are Current. Proposed enhancements are labelled.

## 5.1 Production data flow and trigger — Current

After Bronze processing and append loading into Dedicated SQL Pool, the **Synapse pipeline calls the Azure DevOps API** to trigger the dbt pipeline. The pipeline prepares its execution environment, including **Python and the SQL ODBC driver**, then runs dbt against the `edp` warehouse.

### Current dbt execution order

```text
Synapse pipeline → Azure DevOps pipeline
    ├─ Install Python runtime and SQL ODBC prerequisites
    ├─ dbt seed
    ├─ dbt build: scheduled priority-100 selection(s)
    │      staging, change-key logic, SCD2 and other preparatory models
    └─ dbt build: priority-200 selection
           Silver and Gold domain/data-product models
```

The end-to-end pipeline is ordinarily **about 1–2 hours per day**, varying with data changes and scheduled sources. Do not treat that as an SLA.

**Important nuance:** dbt follows model dependency relationships within a selected build. Scheduling priority phases does not magically allow a model to run before an unbuilt dependency. Any new model must be incorporated into the appropriate phase, and the dependency graph must be valid across phases.

## 5.2 Scheduled selectors — Current conceptual overview

Existing schedules include a daily priority-100 selection, additional day-specific selections (Monday, Tuesday, Wednesday), and source-specific cadence such as **ABF in the Monday selection** and **ABS in the monthly selection**, before the priority-200 Silver/Gold work. The **actual selector names, exact arguments, schedules and source coverage must be read from the repository and Azure DevOps pipeline**.

| Execution phase | Intent | Reviewer concern |
| --- | --- | --- |
| Seed | Load small lookup datasets | Validate seed changes and downstream impact |
| Priority 100 | Stage sources; establish change keys and history | Source availability, SCD2 correctness, upstream ordering |
| Priority 200 | Build domain Silver and consumption Gold | Business semantics, model quality, consumer impact |

**Do not invent selector names.** Capture the actual `dbt build --selector …` or `--select …` arguments from the deployed YAML into an internal schedule appendix when the team reviews this handbook.

## 5.3 What a developer must check before merging

1. Does the model belong in the existing scheduled selector(s)?
2. Are all its upstream dependencies guaranteed to exist or build in an earlier/current phase?
3. Is it materialised correctly for the target dedicated SQL pool?
4. Does the change add unnecessary processing to every daily run?
5. Does it require a one-off backfill or data correction?
6. Are there warehouse concurrency, memory or storage implications?
7. Does it change access to a Silver/Gold schema or a consumer contract?

**Proposed automation:** Add CI checks to report missing model metadata, unselected new nodes, invalid cross-phase dependencies, unexpected production target configuration and unapproved schema additions.

## 5.4 Ownership and mandatory production approvals — Current

| Change | Responsible engineering area | Production authority |
| --- | --- | --- |
| Source YAML or source onboarding/Bronze Spark | Data Engineering | Lead Data Engineer |
| Synapse pipeline or Azure DevOps deployment plumbing | Data Engineering | Lead Data Engineer |
| Staging/intermediate model supporting Silver/Gold | Analytics Engineering; coordinate cross-layer implications | Follow the relevant Silver/Gold release authority where affected |
| Silver or Gold transformation | Analytics Engineering | **Director of Data Operations** |
| Any **new Silver table** | Analytics Engineering | **Explicit Director of Data Operations approval** |
| Mixed upstream and downstream change | Data + Analytics Engineering | Both relevant sign-offs |

Actual branch protection and approval records should document how sign-off is collected. Do not substitute a generic PR approval for the named release authority.

## 5.5 Release evidence — Proposed standard

Every production-facing PR should include a concise evidence set:

- Work item and source of requested business definition.
- Old/new relation names and known downstream dependencies.
- YAML descriptions/tests and test results.
- Development run logs with successful completion/known exceptions.
- Impact assessment for downstream Power BI models, reports and apps.
- Anticipated run-time/row-volume effect for large models.
- Backfill/rebuild approach if history or grain changes.
- Recovery/rollback plan and post-release verification owner.
- Required sign-off captured before deployment.

## 5.6 Rollback and recovery

dbt code can be reverted in Git, but **reverting a commit does not automatically reverse data changes**. Before a risky release, decide:

- Can the affected Silver/Gold tables be rebuilt from controlled `_SRC`/Bronze inputs?
- Is there a known-good prior table/version or alternative safe restoration method?
- Does a new column or relation create breaking downstream view/Power BI dependencies?
- Are there manual downstream changes or external consumers to coordinate?
- If a CTAS/table-swap is planned, are table renames, locks and invalidated views accounted for?

**Current architectural principle:** TDI is intended to be recoverable from Bronze and version-controlled transformations. The practical restore steps and recovery times vary by system and should be exercised, not assumed.

### Incident escalation

- **Landing/Bronze `_SRC` problem:** contact Data Engineering / Lead Data Engineer.
- **dbt Silver/Gold logic, data quality, failed build:** contact Analytics Engineering and notify the Director when production/data-product impact exists.
- **SQL pool performance or cross-platform outage:** coordinate both teams and platform support.
- **Incorrect business definition or access exposure:** involve the accountable business owner and Director immediately.

## 5.7 Enhancements to prioritise — Proposed

1. Generate `manifest.json` and `run_results.json` for every production run; retain artifacts securely according to policy.
2. Publish a schedule/selector inventory and show missing model coverage.
3. Publish dbt Docs internally after validated builds.
4. Add an operational dashboard with model runtimes, failure trends, test failures and freshness/lag signals where supported.
5. Build a formal release checklist based on the [PR template](templates/pull-request-template.md).
