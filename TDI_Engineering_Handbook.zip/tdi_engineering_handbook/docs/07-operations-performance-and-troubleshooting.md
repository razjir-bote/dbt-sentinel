# 07 — Operations, performance and troubleshooting

[← Handbook home](../README.md) · [← Quality](06-quality-metadata-and-lineage.md) · [Next: onboarding →](08-new-engineer-onboarding.md)

**Status:** TDI technology and orchestration are Current. Troubleshooting procedures and recommendations are Proposed and must be checked against approved operational runbooks.

## 7.1 First five questions for a failed run

1. **Where did it fail?** Source integration, Landing, Bronze Spark, append load, Azure DevOps setup, dbt model or data test?
2. **When?** Which production run, schedule, source, deployment and model version?
3. **What changed?** Incoming source shape/volume, SQL, YAML, package, credentials or permissions?
4. **What is affected?** One model, downstream Silver/Gold, data access or a published consumer?
5. **Can it be safely retried?** Check append/idempotency and history semantics before replaying a source or model.

Do not repeatedly re-run a failed production load without understanding whether it duplicates append-only data.

## 7.2 Evidence to collect

| Evidence | Why it matters |
| --- | --- |
| Azure DevOps pipeline run ID, start/end time, job/step | Distinguishes setup, selection and execution failures |
| Synapse pipeline activity/run ID | Establishes upstream ingestion/trigger state |
| dbt invocation and selected target/selector | Confirms what actually ran |
| `target/run_results.json` | Node outcomes, execution times and failures |
| `target/manifest.json` | Model configuration, compiled graph, resource metadata |
| Relevant dbt logs | Compiler, adapter and warehouse errors |
| SQL pool request/query IDs and workload metrics | Diagnoses waits, memory, skew and data movement |
| Row counts / key counts / test results | Determines whether a failure affected data correctness |

Store artifacts and logs only in approved locations and redact sensitive values.

## 7.3 Troubleshooting playbook

| Symptom | Likely area to investigate | First safe action |
| --- | --- | --- |
| Missing rows from a source | Source delivery / Landing / Bronze / `_SRC` | Compare last received source file/change window and Bronze load status |
| `source()` or `ref()` compilation error | dbt declarations or model rename | Run `dbt parse`, inspect model names and YAML definitions |
| Cannot connect / permission denied | `profiles.yml`, Entra access, SQL pool availability | Verify target and access package; use `dbt debug` |
| Failed data test | Source change or transformation regression | Query failing rows in dev/approved read-only environment |
| Unexpected duplicate current records | SCD2/dedup ordering, repeat deliveries | Inspect `(entity_id, versionnumber)` and valid-interval construction |
| Model is slow | Expensive view chain, join movement, table distribution, data size | Inspect query plan, row counts and upstream materialisations |
| Columnstore out-of-memory | Wide columns, memory grant, resource class, CCI | Test alternate table/index/load strategy; do not blindly raise DWU |
| Gold table changed but report stale | Power BI semantic refresh/caching/lineage | Confirm Gold data first, then semantic model refresh and report dependencies |
| Schedule skipped a new model | Selector membership / tag/path criteria | Compare actual selector definitions and `dbt ls --selector` output |

## 7.4 Synapse performance rules of thumb

- **Distribution matters.** Use `HASH` where stable large-table joins support it and skew is acceptable; `ROUND_ROBIN` is often suitable for fast staging but can increase data movement; `REPLICATE` can help small dimensions.
- **Columnstore is not universal.** Wide tables and memory-constrained builds can fail during CCI creation or create poor rowgroups. Assess table width, cardinality, memory class and indexing strategy.
- **Too many tiny partitions hurt.** Dedicated SQL Pool distributes data across compute distributions; overpartitioning can leave sparse columnstore rowgroups.
- **Materialise expensive joins when justified.** A small view may be preferable to a persisted table, but deeply nested view chains can create costly repeated work.
- **Profile before changing compute.** Compare prior durations and query statistics; avoid guessing that higher DWUs alone solve a bad distribution or data-model design.
- **Avoid unnecessary wide scans.** Select needed columns instead of repeatedly scanning large, wide Dynamics 365 tables.

**Operational precedent:** The team has encountered memory pressure trying to construct clustered columnstore tables in a large Synapse workload. This is a design consideration, not a blanket ban on CCI.

## 7.5 Operational health dashboard — Proposed

A useful dbt observability dashboard should report:

| Measure | How to derive/interpret |
| --- | --- |
| Pipeline success rate | Counts of succeeded, failed and cancelled executions over time |
| Build duration | End-to-end and per model; compare with baseline and schedule |
| Slowest models | Per-node execution-time trend from run results |
| Test failures | Per test, model, domain, severity and first observed date |
| Last successful run | Time of last successful materialisation per critical node |
| Source staleness | Source-specific arrival timestamp/availability, where captured |
| Data volume | Row count and data size by domain / product (data steward view) |
| Lineage impact | Models and reports dependent on a failed or late-running model |
| Runtime hotspots | Heavy joins, source reprocessing, data movement, resource waits |

`manifest.json` is the dbt graph/config source; `run_results.json` captures run outcomes. Additional history storage is needed for trends; a single run artifact does not provide complete longitudinal observability. Verify the semantics of run status and timings before calculating metrics.

## 7.6 Recovery playbook — Proposed outline

**If the Bronze/source layer is wrong:** stop downstream promotion where supported, contact Data Engineering, identify source and batch scope, assess append/idempotency, repair/backfill from controlled source data, then replay and reconcile the downstream dependency chain.

**If Silver/Gold logic is wrong:** isolate affected data products, identify last good code and known-good data, decide whether a rebuild from Bronze/`_SRC` is safe, obtain required release approval, deploy via CI/CD, rerun affected models/tests and validate consumers.

**If output schema changed:** investigate whether dependent SQL views, semantic models, Excel connections or applications need updates. Rename/swap operations can invalidate external references even when dbt itself compiles.

## 7.7 Incident note template

```text
Incident reference:
Start / detected / recovered (timezone):
Affected source(s), model(s), schema(s) and consumers:
What failed, including run ID and error excerpt:
Current data correctness assessment:
Immediate containment:
Root cause and evidence:
Replay/backfill or rollback plan:
Approvals and communications:
Validation evidence and close-out owner:
Follow-up prevention action:
```

The exact incident-management system and escalation contacts should be linked here after internal validation; do not invent them.
