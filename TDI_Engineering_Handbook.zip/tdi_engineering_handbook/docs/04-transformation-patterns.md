# 04 — Transformation patterns

[← Handbook home](../README.md) · [← Development](03-development-workflow.md) · [Next: orchestration →](05-orchestration-and-release-governance.md)

**Status:** TDI Dynamics history requirement and core layer responsibilities are Current. Example SQL and recommended decision rules are Proposed.

## 4.1 Source staging — one stable vocabulary

Build staging models close to source data. A staging model should expose consistently named and typed columns while preserving essential source identifiers and change-tracking metadata.

**Recommended staging steps:**

1. Declare the input via `source()` or a documented parent `ref()`.
2. Preserve immutable source identifiers (`entity_id`, `versionnumber`, source timestamps, if available).
3. Rename source-specific fields to stable snake-case concepts.
4. Perform **safe** casts and standardise explicitly known sentinels/nulls.
5. Do not drop historical rows or silently deduplicate unless the source contract requires it and the effect is documented.
6. Keep sensitive columns only where legitimate downstream requirements exist.

```sql
-- Illustrative: fields and source name must be adapted to an actual table.
with source_rows as (
    select
        entity_id,
        versionnumber,
        modifiedon,
        name
    from {{ source('ace_src', 'account') }}
)
select
    entity_id,
    versionnumber,
    modifiedon as source_modified_at,
    name as organisation_name
from source_rows
```

**Why this matters:** Source schemas can be wide, renamed or appended over time. A predictable staging layer decouples business logic from upstream schema quirks.

## 4.2 Deduplicate deterministically

Duplicates can arise from source delivery, repeated loads or retries. Determine the logical key **before** deleting rows.

- For a current-state table, define one survivor per business key (for example, `entity_id`).
- For history, define one survivor per **business key + source version** (for example, `entity_id`, `versionnumber`).
- Choose a stable tie-breaker from available source metadata (such as event/ingestion timestamp and an immutable load ID).
- If there is no deterministic ordering column, **do not rely on arbitrary `row_number()` ordering**. Define the gap with Data Engineering first.

```sql
-- Example only: this requires a real, reliable ingestion_timestamp column.
with ranked as (
    select
        entity_id,
        versionnumber,
        ingestion_timestamp,
        row_number() over (
            partition by entity_id, versionnumber
            order by ingestion_timestamp desc
        ) as duplicate_rank
    from {{ ref('stg_ace__account') }}
)
select entity_id, versionnumber, ingestion_timestamp
from ranked
where duplicate_rank = 1
```

If two records share the same timestamp, add a stable secondary tie-breaker. Keep discarded rows discoverable for assurance where feasible.

## 4.3 Dynamics 365 version-based SCD2 — Current requirement

For Dynamics 365 data delivered through Synapse Link, TDI receives an initial snapshot followed by append-loaded changed records. **The generic history approach uses `entity_id` and the source `versionnumber`: any new version number constitutes a new entity version.** Engineers do **not** maintain per-table attribute lists to detect change. There is no separate initial-snapshot branch and no assumed `is_deleted` logic in this generic pattern.

### Required logical steps

1. Read all relevant changed rows for the entity from the source/staging table.
2. Remove duplicate deliveries of the same `(entity_id, versionnumber)` deterministically.
3. Preserve one historical record for every distinct source version per entity.
4. Order versions using a **validated version ordering rule**. Confirm its data type and behaviour for your source; do not assume lexicographic string order is correct.
5. Use `lead()` or an equivalent window expression to determine the next version boundary.
6. Assign validity start/end fields using an **approved temporal policy** (source modified timestamp where reliable; otherwise documented ingestion-effective time). The next version's effective time may be the previous version's exclusive upper bound.
7. Mark the last version as current; check exactly one current row per entity unless the dataset explicitly permits none.
8. Verify late-arriving events, ties, non-monotonic source timestamps, replays and backfills.

### Worked logical example

| entity_id | versionnumber | effective_from | effective_to (exclusive) | is_current |
| --- | --- | --- | --- | --- |
| A | 1001 | 2026-01-01 | 2026-02-04 | false |
| A | 1002 | 2026-02-04 | 2026-05-11 | false |
| A | 1004 | 2026-05-11 | NULL | true |

The dates above are **illustrative**. Source versions can skip numbers; do not invent missing versions. **Version order and temporal validity are not necessarily the same thing.** If version order conflicts with timestamps, log/resolve according to the approved history policy rather than hiding the record.

### SCD2 validation tests

- Every `(entity_id, versionnumber)` occurs once in the curated history.
- At most one `is_current = true` row per `entity_id`.
- No overlapping validity intervals for one entity.
- `valid_from < valid_to` when `valid_to` is populated.
- The expected number of versions matches distinct staged source versions (after explicitly documented exclusions).
- Business consumers can explain whether they need **current state**, **as-at time**, or **all versions**.

**Do not deploy a generic history macro until it is proven on several real tables**, including wide tables and difficult changes. A version-based strategy is simpler than attribute-by-attribute comparison, but it does not remove the need to understand source delivery semantics.

## 4.4 Silver domain models

Silver should contain **reusable domain concepts**, not assumptions tailored to a single report. A Silver model design should answer:

- What does one row mean?
- What entity identifiers and keys remain stable?
- Is this current-state or historical data?
- What transformations/filters are domain-wide, not report-specific?
- Which source and stewardship owner agrees with the definition?

**Example:** A current-state `slv_organisation` table may choose the latest valid version from an upstream version-history model, with one row per organisation; the history model itself remains accessible where there is a legitimate use case.

**Current governance:** A **new Silver table must be approved by the Director of Data Operations before production publication**.

## 4.5 Gold data products

Gold models should have an explicit **consumer contract**: report/application, business definition, grain, expected refresh and ownership. They may aggregate or denormalise Silver datasets for consumption but should not become an alternate undocumented source of master-data truth.

For a Gold aggregate, document:

- Aggregation keys and reporting period (calendar/fiscal, timezone where relevant).
- Currency, units and other dimensional filters.
- Handling of missing or invalid source values.
- Reconciliation method to the underlying Silver detail.
- Consumer responsibilities when a definition changes.

## 4.6 Full-refresh, incremental and large tables

Use persisted tables for workloads where repeated processing is costly, but make refresh and recovery behaviour explicit.

| Approach | Consider when | Required safeguards |
| --- | --- | --- |
| Full rebuild | Manageable table size; simple history or stable logic | Runtime benchmark, consistency tests, release window |
| Incremental | Large model and reliable change signal | Idempotency, late arrivals, replay/backfill design, tested adapter behaviour |
| Staged CTAS/swap | Large table replacement with tested Synapse pattern | Dependency review, rename locks, permissions, rollback and view invalidation |

**Synapse-specific caution:** A default clustered columnstore index can be counterproductive or fail under memory pressure on very wide tables. Evaluate heap/clustered-index alternatives, distribution, load resource class and rowgroup health using actual data. A `ROUND_ROBIN` distribution may load quickly but cause costly movement on joins.

## 4.7 When to write a reusable macro

Create a macro only after at least two genuine use cases confirm a shared pattern. Document inputs, assumptions, adapter constraints, compile-time SQL, error modes and tests. Genericity is helpful only when it does not conceal different business semantics. Put macro rationale in a decision record where the abstraction is consequential.
